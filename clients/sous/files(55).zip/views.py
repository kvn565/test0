# clients/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from .models import Client, TypeClient
from .forms import ClientForm, TypeClientForm


# ═══════════════════════════════════════════════
#  TYPES DE CLIENT
# ═══════════════════════════════════════════════
def types_clients(request):
    types = TypeClient.objects.all()
    return render(request, 'clients/types.html', {
        'types': types,
        'total': types.count(),
    })


def creer_type_client(request):
    if request.method == 'POST':
        form = TypeClientForm(request.POST)
        if form.is_valid():
            t = form.save()
            messages.success(request, f"Type « {t.nom} » créé avec succès.")
            return redirect('clients:types')
    else:
        form = TypeClientForm()
    return render(request, 'clients/creer_type.html', {
        'form':  form,
        'titre': 'Nouveau type de client',
        'action': 'Créer',
    })


def edit_type_client(request, pk):
    type_client = get_object_or_404(TypeClient, pk=pk)
    if request.method == 'POST':
        form = TypeClientForm(request.POST, instance=type_client)
        if form.is_valid():
            form.save()
            messages.success(request, f"Type « {type_client.nom} » modifié.")
            return redirect('clients:types')
    else:
        form = TypeClientForm(instance=type_client)
    return render(request, 'clients/creer_type.html', {
        'form':        form,
        'titre':       'Modifier le type de client',
        'action':      'Enregistrer',
        'type_client': type_client,
    })


def delete_type_client(request, pk):
    # ✅ CORRIGÉ : confirmation POST obligatoire
    type_client = get_object_or_404(TypeClient, pk=pk)
    if request.method == 'POST':
        nom = type_client.nom
        type_client.delete()
        messages.success(request, f"Type « {nom} » supprimé.")
        return redirect('clients:types')
    return render(request, 'clients/delete_type.html', {'type_client': type_client})


# ═══════════════════════════════════════════════
#  CLIENTS
# ═══════════════════════════════════════════════
def liste_clients(request):
    q = request.GET.get('q', '')
    clients = Client.objects.select_related('type_client').all()
    if q:
        clients = clients.filter(
            Q(nom__icontains=q) | Q(nif__icontains=q) | Q(adresse__icontains=q)
        )
    return render(request, 'clients/liste.html', {
        'clients': clients,
        'q':       q,
        'total':   Client.objects.count(),
    })


def creer_client(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            c = form.save()
            messages.success(request, f"Client « {c.nom} » créé avec succès.")
            return redirect('clients:liste')
    else:
        form = ClientForm()
    return render(request, 'clients/creer.html', {
        'form':   form,
        'titre':  'Nouveau client',
        'action': 'Créer',
    })


def edit_client(request, pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            messages.success(request, f"Client « {client.nom} » modifié.")
            return redirect('clients:liste')
    else:
        form = ClientForm(instance=client)
    return render(request, 'clients/creer.html', {
        'form':   form,
        'titre':  'Modifier le client',
        'action': 'Enregistrer',
        'client': client,
    })


def delete_client(request, pk):
    # ✅ CORRIGÉ : confirmation POST obligatoire
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        nom = client.nom
        client.delete()
        messages.success(request, f"Client « {nom} » supprimé.")
        return redirect('clients:liste')
    return render(request, 'clients/delete_client.html', {'client': client})
