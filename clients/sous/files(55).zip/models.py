# clients/models.py
from django.db import models


class TypeClient(models.Model):
    nom = models.CharField(max_length=100, unique=True, verbose_name="Type de client")

    class Meta:
        verbose_name = "Type de client"
        verbose_name_plural = "Types de clients"
        ordering = ['nom']

    def __str__(self):
        return self.nom


class Client(models.Model):
    ASSUJETI_CHOICES = [
        (True,  'Oui'),
        (False, 'Non'),
    ]

    nom           = models.CharField(max_length=150, verbose_name="Nom du client")
    nif           = models.CharField(max_length=50, blank=True, null=True, verbose_name="NIF")
    assujeti_tva  = models.BooleanField(choices=ASSUJETI_CHOICES, default=False, verbose_name="Assujetti TVA")
    adresse       = models.CharField(max_length=200, blank=True, null=True, verbose_name="Adresse / Résidence")
    type_client   = models.ForeignKey(TypeClient, on_delete=models.SET_NULL, null=True, related_name='clients', verbose_name="Type de client")
    date_creation = models.DateField(auto_now_add=True)

    class Meta:
        verbose_name = "Client"
        verbose_name_plural = "Clients"
        ordering = ['nom']

    def __str__(self):
        return f"{self.nom} ({self.type_client})"
