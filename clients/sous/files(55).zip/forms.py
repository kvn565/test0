# clients/forms.py
from django import forms
from .models import Client, TypeClient


class TypeClientForm(forms.ModelForm):
    class Meta:
        model = TypeClient
        fields = ['nom']
        widgets = {
            'nom': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: Particulier, Entreprise, ONG...',
                'autofocus': True,
            }),
        }
        labels = {
            'nom': 'Nom du type de client',
        }


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['nom', 'nif', 'assujeti_tva', 'adresse', 'type_client']
        widgets = {
            'nom': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: SODECO SA, Jean Dupont...',
            }),
            'nif': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Numéro d\'Identification Fiscale',
            }),
            'assujeti_tva': forms.Select(
                choices=[(True, 'Oui'), (False, 'Non')],
                attrs={'class': 'form-control-custom'},
            ),
            'adresse': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: Avenue de la Paix, Bujumbura',
            }),
            'type_client': forms.Select(attrs={
                'class': 'form-control-custom',
            }),
        }
        labels = {
            'nom':          'Nom du client',
            'nif':          'NIF',
            'assujeti_tva': 'Assujetti TVA',
            'adresse':      'Adresse / Résidence',
            'type_client':  'Type de client',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['nif'].required         = False
        self.fields['adresse'].required     = False
        self.fields['type_client'].required = False
        self.fields['type_client'].empty_label = '-- Sélectionner un type --'
        self.fields['type_client'].queryset = TypeClient.objects.all().order_by('nom')
