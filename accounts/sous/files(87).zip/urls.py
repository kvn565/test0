# account/urls.py

from django.urls import path
from . import views

app_name = 'account'

urlpatterns = [
    path('login/',          views.login_view,          name='login'),
    path('logout/',         views.logout_view,          name='logout'),
    path('setup/',          views.setup_view,           name='setup'),
    path('attente/',        views.attente_view,         name='attente'),
    path('inactif/',        views.inactif_view,         name='inactif'),
    path('suspendu/',       views.suspendu_view,        name='suspendu'),
    path('activer/',        views.activer_licence_view, name='activer_licence'),
]
