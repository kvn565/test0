# account/forms.py

from django import forms
from superadmin.models import CleActivation, Utilisateur


# ─────────────────────────────────────────────
#  CONNEXION
# ─────────────────────────────────────────────

class ConnexionForm(forms.Form):
    username = forms.CharField(
        label="Nom d'utilisateur",
        max_length=150,
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': "Votre nom d'utilisateur",
            'autofocus': True,
            'autocomplete': 'username',
        }),
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={
            'class': 'form-input',
            'placeholder': '••••••••',
            'autocomplete': 'current-password',
        }),
    )
    remember = forms.BooleanField(
        label="Se souvenir de moi",
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'checkbox'}),
    )


# ─────────────────────────────────────────────
#  SETUP — ACTIVATION PAR CLÉ
# ─────────────────────────────────────────────

class SetupActivationForm(forms.Form):
    """
    Formulaire d'activation initial.
    Le chef reçoit une clé du superadmin et l'utilise pour activer sa société.
    La société est déjà enregistrée par le superadmin — le chef crée son compte ici.
    """

    # ── Clé d'activation ────────────────────────────────────────
    cle_activation = forms.CharField(
        label="Clé d'activation",
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input mono',
            'placeholder': 'Ex : SOD-3456-12M-AB3D4E',
            'autocomplete': 'off',
            'style': 'text-transform:uppercase; letter-spacing: 2px;',
        }),
        help_text="Clé reçue de l'administrateur système (format : NOM-NIF-PLAN-CODE)",
    )

    # ── NIF de la société ────────────────────────────────────────
    nif = forms.CharField(
        label="NIF de votre société",
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': 'Ex : 4000123456',
            'autocomplete': 'off',
        }),
        help_text="Numéro d'Identification Fiscale de votre société",
    )

    # ── Identité chef ────────────────────────────────────────────
    nom     = forms.CharField(label="Nom",     max_length=100, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex: NDAYISHIMIYE'}))
    postnom = forms.CharField(label="Post-nom", max_length=100, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex: JEAN'}))
    prenom  = forms.CharField(label="Prénom",  max_length=100, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex: Pierre'}))
    email   = forms.EmailField(
        label="Email", required=False,
        widget=forms.EmailInput(attrs={'class': 'form-input', 'placeholder': 'votre@email.com'}),
    )

    # ── Identifiants de connexion ────────────────────────────────
    username = forms.CharField(
        label="Nom d'utilisateur",
        max_length=150,
        min_length=4,
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': 'Ex: jean.ndayishimiye',
            'autocomplete': 'off',
        }),
        help_text="Minimum 4 caractères — utilisé pour vous connecter",
    )
    password1 = forms.CharField(
        label="Mot de passe",
        min_length=6,
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': '••••••••'}),
        help_text="Minimum 6 caractères",
    )
    password2 = forms.CharField(
        label="Confirmer le mot de passe",
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': '••••••••'}),
    )

    # ── Validations ──────────────────────────────────────────────

    def clean_cle_activation(self):
        return self.cleaned_data.get('cle_activation', '').strip().upper()

    def clean_nif(self):
        return self.cleaned_data.get('nif', '').strip()

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if Utilisateur.objects.filter(username=username).exists():
            raise forms.ValidationError("Ce nom d'utilisateur est déjà pris.")
        return username

    def clean(self):
        cleaned = super().clean()

        # Vérifier les mots de passe
        p1 = cleaned.get('password1')
        p2 = cleaned.get('password2')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError({'password2': "Les mots de passe ne correspondent pas."})

        # Vérifier la clé d'activation + NIF
        cle_saisie = cleaned.get('cle_activation')
        nif_saisi  = cleaned.get('nif')

        if cle_saisie and nif_saisi:
            success, message, cle_obj = CleActivation.verifier_pour_setup(cle_saisie, nif_saisi)
            if not success:
                raise forms.ValidationError({'cle_activation': message})
            cleaned['_cle_obj'] = cle_obj

        return cleaned
