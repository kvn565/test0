# account/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction

from .forms import ConnexionForm, SetupActivationForm
from superadmin.models import Utilisateur, HistoriqueConnexion, CleActivation
from societe.models import Societe


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────

def _get_ip(request):
    return (
        request.META.get('HTTP_X_FORWARDED_FOR', '').split(',')[0].strip()
        or request.META.get('REMOTE_ADDR')
    )

def _get_statut_societe(societe):
    """
    Retourne le statut actuel de la société basé sur ses clés d'activation.
    Miroir du PHP : statut_approbation, essai_actif, statut.
    """
    from datetime import date
    today = date.today()

    cle_active = societe.cles_activation.filter(
        statut='ACTIVE',
        date_debut__lte=today,
        date_fin__gte=today,
    ).first()

    cle_revoquee = societe.cles_activation.filter(statut='REVOQUEE').exists()
    cle_expiree  = societe.cles_activation.filter(
        statut='ACTIVE',
        date_fin__lt=today,
    ).first()

    if cle_active:
        if cle_active.type_plan == 'ESSAI':
            return 'essai_actif', cle_active
        return 'actif', cle_active
    elif cle_expiree:
        return 'essai_expire', cle_expiree
    elif cle_revoquee:
        return 'suspendu', None
    else:
        # Aucune clé → en attente d'attribution de licence
        cle_disponible = societe.cles_activation.filter(statut='DISPONIBLE').exists()
        if cle_disponible:
            return 'en_attente', None
        return 'inactif', None


# ─────────────────────────────────────────────
#  LOGIN
# ─────────────────────────────────────────────

def login_view(request):
    """
    Connexion utilisateur.
    Miroir de login.php — vérifie le statut de la société et redirige en conséquence.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')

    form = ConnexionForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        ip       = _get_ip(request)

        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Vérifier que le compte est actif
            if not user.actif:
                form.add_error(None, "Votre compte a été désactivé. Contactez l'administrateur.")
                HistoriqueConnexion.objects.create(
                    utilisateur=user, adresse_ip=ip,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                )
                return render(request, 'account/login.html', {'form': form})

            # Superadmin → accès direct sans vérification de société
            if user.is_superuser:
                login(request, user)
                HistoriqueConnexion.objects.create(
                    utilisateur=user, adresse_ip=ip,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                )
                return redirect('superadmin:dashboard')

            # Utilisateur normal → vérifier la société
            if not user.societe:
                form.add_error(None, "Aucune société associée à votre compte.")
                return render(request, 'account/login.html', {'form': form})

            societe = user.societe
            statut, cle = _get_statut_societe(societe)

            # Enregistrer la connexion réussie
            login(request, user)
            HistoriqueConnexion.objects.create(
                utilisateur=user, adresse_ip=ip,
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
            )
            user.last_login = timezone.now()
            user.save(update_fields=['last_login'])

            # Redirection selon le statut — miroir de login.php
            if statut == 'en_attente':
                return redirect('account:attente')
            elif statut == 'inactif':
                return redirect('account:inactif')
            elif statut == 'essai_expire':
                return redirect('account:activer_licence')
            elif statut == 'suspendu':
                return redirect('account:suspendu')
            else:
                return redirect('dashboard')

        else:
            # Tentative échouée
            try:
                user_echec = Utilisateur.objects.get(username=username)
                HistoriqueConnexion.objects.create(
                    utilisateur=user_echec, adresse_ip=ip,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                )
            except Utilisateur.DoesNotExist:
                pass
            form.add_error(None, "Identifiants incorrects.")

    return render(request, 'account/login.html', {'form': form})


# ─────────────────────────────────────────────
#  LOGOUT
# ─────────────────────────────────────────────

def logout_view(request):
    """Déconnexion — termine la session."""
    # Marquer la déconnexion dans l'historique
    if request.user.is_authenticated:
        conn = HistoriqueConnexion.objects.filter(
            utilisateur=request.user,
            date_deconnexion__isnull=True,
        ).order_by('-date_connexion').first()
        if conn:
            conn.terminer_session()
    logout(request)
    return redirect('account:login')


# ─────────────────────────────────────────────
#  SETUP — ACTIVATION PAR CLÉ
#  Remplace register.php : le chef reçoit sa clé du superadmin
#  et l'utilise ici pour activer l'accès de sa société.
# ─────────────────────────────────────────────

def setup_view(request):
    """
    Activation initiale de la société par clé.
    Le chef saisit la clé reçue du superadmin + le NIF de sa société.
    La société est déjà enregistrée par le superadmin.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')

    form = SetupActivationForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        cd       = form.cleaned_data
        cle_obj  = cd['_cle_obj']   # injecté par le form.clean()
        societe  = cle_obj.societe

        # Vérifier qu'il n'y a pas déjà un utilisateur chef pour cette société
        chef_existant = Utilisateur.objects.filter(
            societe=societe, is_staff=True
        ).first()
        if chef_existant:
            form.add_error('cle_activation', "Cette société a déjà un compte actif.")
            return render(request, 'account/setup.html', {'form': form})

        try:
            with transaction.atomic():
                # Activer la clé
                cle_obj.activer()

                # Créer l'utilisateur chef / propriétaire
                chef = Utilisateur(
                    societe    = societe,
                    username   = cd['username'],
                    nom        = cd['nom'],
                    postnom    = cd['postnom'],
                    prenom     = cd['prenom'],
                    email      = cd.get('email', ''),
                    type_poste = 'DIRECTEUR',
                    is_staff   = True,          # chef = staff de sa société
                    is_superuser = False,
                    actif      = True,
                    # Tous les droits par défaut pour le chef
                    droit_stock_categorie    = True,
                    droit_stock_produit      = True,
                    droit_stock_fournisseur  = True,
                    droit_stock_entree       = True,
                    droit_stock_sortie       = True,
                    droit_facture_pnb        = True,
                    droit_facture_fdnb       = True,
                    droit_facture_particulier = True,
                    droit_devis              = True,
                    droit_rapports           = True,
                )
                chef.set_password(cd['password1'])
                chef.save()

        except Exception as e:
            form.add_error(None, f"Erreur lors de la création du compte : {e}")
            return render(request, 'account/setup.html', {'form': form})

        messages.success(
            request,
            f"✅ Compte activé avec succès pour « {societe.nom} » ! "
            f"Vous pouvez maintenant vous connecter."
        )
        return redirect('account:login')

    return render(request, 'account/setup.html', {'form': form})


# ─────────────────────────────────────────────
#  PAGES D'ÉTAT — miroir des redirections PHP
# ─────────────────────────────────────────────

@login_required
def attente_view(request):
    """Société en attente d'attribution de licence (miroir attente_approbation.php)."""
    return render(request, 'account/attente.html', {'societe': request.user.societe})


@login_required
def inactif_view(request):
    """Société inactive — aucune clé jamais attribuée."""
    return render(request, 'account/inactif.html', {'societe': request.user.societe})


@login_required
def suspendu_view(request):
    """Société suspendue (miroir compte_suspendu.php)."""
    return render(request, 'account/suspendu.html', {'societe': request.user.societe})


@login_required
def activer_licence_view(request):
    """Essai expiré — demande d'activation d'une nouvelle licence (miroir activer_licence.php)."""
    return render(request, 'account/activer_licence.html', {'societe': request.user.societe})
