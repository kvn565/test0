# services/models.py
from django.db import models

class Service(models.Model):
    designation = models.CharField(max_length=200, unique=True, verbose_name="Désignation")
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Service"
        verbose_name_plural = "Services"
        ordering = ['designation']

    def __str__(self):
        return self.designation
