# services/forms.py
from django import forms
from .models import Service

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['designation']
        widgets = {
            'designation': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: Consultation, Transport, Installation...',
                'autofocus': True,
            })
        }
        labels = {
            'designation': 'Désignation du service',
        }
