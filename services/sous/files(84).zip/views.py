# services/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from .models import Service
from .forms import ServiceForm


def service_liste(request):
    q        = request.GET.get('q', '')
    services = Service.objects.all()
    if q:
        services = services.filter(designation__icontains=q)
    return render(request, 'services/liste.html', {
        'services': services,
        'q':        q,
        'total':    Service.objects.count(),
    })


def service_creer(request):
    if request.method == 'POST':
        form = ServiceForm(request.POST)
        if form.is_valid():
            service = form.save()
            messages.success(request, f"Service « {service.designation} » créé avec succès.")
            return redirect('services:liste')
    else:
        form = ServiceForm()
    return render(request, 'services/form.html', {
        'form':   form,
        'titre':  'Nouveau service',
        'action': 'Créer',
    })


def service_modifier(request, pk):
    service = get_object_or_404(Service, pk=pk)
    if request.method == 'POST':
        form = ServiceForm(request.POST, instance=service)
        if form.is_valid():
            form.save()
            messages.success(request, f"Service « {service.designation} » modifié avec succès.")
            return redirect('services:liste')
    else:
        form = ServiceForm(instance=service)
    return render(request, 'services/form.html', {
        'form':    form,
        'titre':   'Modifier le service',
        'action':  'Enregistrer',
        'service': service,
    })


def service_supprimer(request, pk):
    service = get_object_or_404(Service, pk=pk)
    if request.method == 'POST':
        nom = service.designation
        service.delete()
        messages.success(request, f"Service « {nom} » supprimé.")
        return redirect('services:liste')
    return render(request, 'services/supprimer.html', {'service': service})
