# stock/obr_service.py
"""
Service d'intégration avec l'API eBMS de l'OBR (Office Burundais des Recettes).
Gère l'authentification et l'envoi des mouvements de stock.
"""

import requests
import logging
from datetime import datetime
from django.utils import timezone

logger = logging.getLogger(__name__)

# ─── URLs de l'API OBR ────────────────────────────────────────────────────────
OBR_BASE_URL       = "https://ebms.obr.gov.bi:9443/ebms_api"
URL_LOGIN          = f"{OBR_BASE_URL}/login/"
URL_STOCK_LOCAL    = f"{OBR_BASE_URL}/AddStockMovement/"
URL_STOCK_IMPORTE  = f"{OBR_BASE_URL}/AddStockMovementImporters/"

TIMEOUT = 30  # secondes


# ══════════════════════════════════════════════════════════════════════════════
#  AUTHENTIFICATION
# ══════════════════════════════════════════════════════════════════════════════

def get_token_obr(societe):
    """
    Obtient un jeton d'accès OBR pour la société donnée.
    Le token expire après 60 secondes — à appeler juste avant chaque envoi.

    Pré-requis : la société doit avoir les champs 'obr_username' et 'obr_password'.
    """
    username = getattr(societe, 'obr_username', None)
    password = getattr(societe, 'obr_password', None)

    if not username or not password:
        raise ValueError(
            f"La société '{societe}' n'a pas de credentials OBR configurés "
            "(obr_username / obr_password manquants)."
        )

    try:
        response = requests.post(
            URL_LOGIN,
            json={"username": username, "password": password},
            headers={"Content-Type": "application/json"},
            timeout=TIMEOUT,
            verify=True,
        )
        data = response.json()

        if response.status_code == 200 and data.get("success"):
            return data["result"]["token"]
        else:
            raise ConnectionError(
                f"Échec authentification OBR : {data.get('msg', 'Erreur inconnue')}"
            )

    except requests.exceptions.RequestException as e:
        raise ConnectionError(f"Impossible de joindre le serveur OBR : {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENVOI ENTRÉE STOCK
# ══════════════════════════════════════════════════════════════════════════════

def envoyer_entree_stock(entree):
    """
    Envoie une entrée stock à l'OBR via l'API AddStockMovement
    ou AddStockMovementImporters si le produit est importé.

    Retourne (success: bool, message: str)
    """
    from .models import EntreeStock

    societe = entree.societe
    produit = entree.produit

    # Déterminer si c'est un produit importé
    est_importe = getattr(produit, 'origine', '').upper() == 'IMPORTE'
    url = URL_STOCK_IMPORTE if est_importe else URL_STOCK_LOCAL

    # Récupérer le system_id de la société (identifiant fourni par l'OBR)
    system_id = getattr(societe, 'obr_system_id', '')
    if not system_id:
        return False, "Le system_id OBR de la société n'est pas configuré."

    # Formater la date
    date_mvt = datetime.combine(entree.date_entree, datetime.min.time())
    date_mvt_str = date_mvt.strftime("%Y-%m-%d %H:%M:%S")

    # Corps de la requête commun
    payload = {
        "system_or_device_id":          str(system_id),
        "item_code":                     str(produit.code),
        "item_designation":              str(produit.designation),
        "item_quantity":                 str(entree.quantite),
        "item_measurement_unit":         str(produit.unite),
        "item_purchase_or_sale_price":   str(entree.prix_revient),
        "item_purchase_or_sale_currency": "BIF",
        "item_movement_type":            str(entree.type_entree),
        "item_movement_invoice_ref":     str(entree.numero_ref) if entree.numero_ref else "",
        "item_movement_description":     "",
        "item_movement_date":            date_mvt_str,
    }

    # Champs supplémentaires pour les marchandises importées
    if est_importe:
        payload["reference_dmc"]      = str(getattr(produit, 'reference_dmc', ''))
        payload["rubrique_tarifaire"] = str(getattr(produit, 'rubrique_tarifaire', ''))
        payload["nombre_par_paquet"]  = str(getattr(produit, 'nombre_par_paquet', '1'))
        payload["description_paquet"] = str(getattr(produit, 'description_paquet', ''))

    try:
        token = get_token_obr(societe)

        response = requests.post(
            url,
            json=payload,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {token}",
            },
            timeout=TIMEOUT,
            verify=True,
        )
        data = response.json()

        if response.status_code == 200 and data.get("success"):
            # Mise à jour du statut dans la base
            EntreeStock.objects.filter(pk=entree.pk).update(
                statut_obr     = 'ENVOYE',
                message_obr    = data.get('msg', 'Envoyé avec succès'),
                date_envoi_obr = timezone.now(),
            )
            logger.info(f"[OBR] Entrée stock #{entree.pk} envoyée avec succès.")
            return True, data.get('msg', 'Envoyé avec succès')
        else:
            msg = data.get('msg', 'Erreur inconnue')
            EntreeStock.objects.filter(pk=entree.pk).update(
                statut_obr  = 'ECHEC',
                message_obr = msg,
            )
            logger.warning(f"[OBR] Échec envoi entrée stock #{entree.pk} : {msg}")
            return False, msg

    except (ConnectionError, ValueError) as e:
        EntreeStock.objects.filter(pk=entree.pk).update(
            statut_obr  = 'ECHEC',
            message_obr = str(e),
        )
        logger.error(f"[OBR] Erreur entrée stock #{entree.pk} : {e}")
        return False, str(e)


# ══════════════════════════════════════════════════════════════════════════════
#  ENVOI SORTIE STOCK
# ══════════════════════════════════════════════════════════════════════════════

def envoyer_sortie_stock(sortie):
    """
    Envoie une sortie stock à l'OBR via l'API AddStockMovement.
    Les sorties utilisent toujours l'endpoint standard (pas Importers).

    Retourne (success: bool, message: str)
    """
    from .models import SortieStock

    societe = sortie.societe
    produit = sortie.produit

    system_id = getattr(societe, 'obr_system_id', '')
    if not system_id:
        return False, "Le system_id OBR de la société n'est pas configuré."

    date_mvt = datetime.combine(sortie.date_sortie, datetime.min.time())
    date_mvt_str = date_mvt.strftime("%Y-%m-%d %H:%M:%S")

    # Référence de facture pour les retours marchandises
    invoice_ref = ""
    if sortie.type_sortie == 'SR' and sortie.code:
        invoice_ref = str(sortie.code)

    payload = {
        "system_or_device_id":          str(system_id),
        "item_code":                     str(produit.code),
        "item_designation":              str(produit.designation),
        "item_quantity":                 str(sortie.quantite),
        "item_measurement_unit":         str(produit.unite),
        "item_purchase_or_sale_price":   str(sortie.prix),
        "item_purchase_or_sale_currency": "BIF",
        "item_movement_type":            str(sortie.type_sortie),
        "item_movement_invoice_ref":     invoice_ref,
        "item_movement_description":     str(sortie.commentaire) if sortie.commentaire else "",
        "item_movement_date":            date_mvt_str,
    }

    try:
        token = get_token_obr(societe)

        response = requests.post(
            URL_STOCK_LOCAL,
            json=payload,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {token}",
            },
            timeout=TIMEOUT,
            verify=True,
        )
        data = response.json()

        if response.status_code == 200 and data.get("success"):
            SortieStock.objects.filter(pk=sortie.pk).update(
                statut_obr     = 'ENVOYE',
                message_obr    = data.get('msg', 'Envoyé avec succès'),
                date_envoi_obr = timezone.now(),
            )
            logger.info(f"[OBR] Sortie stock #{sortie.pk} envoyée avec succès.")
            return True, data.get('msg', 'Envoyé avec succès')
        else:
            msg = data.get('msg', 'Erreur inconnue')
            SortieStock.objects.filter(pk=sortie.pk).update(
                statut_obr  = 'ECHEC',
                message_obr = msg,
            )
            logger.warning(f"[OBR] Échec envoi sortie stock #{sortie.pk} : {msg}")
            return False, msg

    except (ConnectionError, ValueError) as e:
        SortieStock.objects.filter(pk=sortie.pk).update(
            statut_obr  = 'ECHEC',
            message_obr = str(e),
        )
        logger.error(f"[OBR] Erreur sortie stock #{sortie.pk} : {e}")
        return False, str(e)


# ══════════════════════════════════════════════════════════════════════════════
#  RÉENVOI MANUEL (pour les échecs)
# ══════════════════════════════════════════════════════════════════════════════

def reenvoyer_entrees_en_echec(societe):
    """
    Réessaie d'envoyer toutes les entrées en statut ECHEC ou EN_ATTENTE.
    À appeler manuellement ou via une tâche planifiée (Celery, cron...).
    """
    from .models import EntreeStock
    entrees = EntreeStock.objects.filter(
        societe=societe,
        statut_obr__in=['ECHEC', 'EN_ATTENTE']
    )
    resultats = []
    for entree in entrees:
        success, msg = envoyer_entree_stock(entree)
        resultats.append({'id': entree.pk, 'success': success, 'msg': msg})
    return resultats


def reenvoyer_sorties_en_echec(societe):
    """
    Réessaie d'envoyer toutes les sorties en statut ECHEC ou EN_ATTENTE.
    """
    from .models import SortieStock
    sorties = SortieStock.objects.filter(
        societe=societe,
        statut_obr__in=['ECHEC', 'EN_ATTENTE']
    )
    resultats = []
    for sortie in sorties:
        success, msg = envoyer_sortie_stock(sortie)
        resultats.append({'id': sortie.pk, 'success': success, 'msg': msg})
    return resultats
