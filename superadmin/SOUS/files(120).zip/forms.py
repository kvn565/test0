# superadmin/forms.py — VERSION FINALE
# ✅ SocieteForm       : enregistrement société par le superadmin (clé essai auto)
# ✅ CleActivationForm : génération clé payante (Starter/Business/Enterprise)
# ✅ InscriptionChefForm : inscription du chef via NIF autorisé (remplace SetupCompletForm)
# ✅ ClePayanteForm       : saisie clé payante après expiration essai
# ✅ LOGIQUE : superadmin crée société → clé essai 14j auto → chef s'inscrit via NIF

from datetime import timedelta
from django import forms
from django.utils import timezone
from django.contrib.auth.forms import UserCreationForm
from .models import CleActivation, Utilisateur
from societe.models import Societe


# ═══════════════════════════════════════════════════════════════
#  SOCIÉTÉ — champs originaux
# ═══════════════════════════════════════════════════════════════

class SocieteForm(forms.ModelForm):
    """
    Formulaire de création d'une société par le SUPERADMIN.

    Le superadmin saisit UNIQUEMENT :
      - Le nom de la société
      - Le NIF (clé d'accès unique pour le chef)

    La clé d'essai 14 jours est activée AUTOMATIQUEMENT.
    Le chef complète toutes les autres informations à son inscription.
    Le superadmin peut ensuite comparer les infos saisies par le chef
    depuis la fiche détail de la société.
    """
    class Meta:
        model  = Societe
        fields = ['nom', 'nif']   # ✅ Minimum requis — le reste est complété par le chef
        widgets = {
            'nom': forms.TextInput(attrs={
                'class': 'form-control form-control-lg',
                'placeholder': 'Ex: SODECO SARL',
                'autofocus': 'autofocus',
            }),
            'nif': forms.TextInput(attrs={
                'class': 'form-control form-control-lg',
                'placeholder': 'Ex: 4000123456',
                'style': 'font-family: monospace; font-weight: bold;',
            }),
        }
        labels = {
            'nom': 'Nom de la société',
            'nif': 'NIF (Numéro d\'Identification Fiscale)',
        }
        help_texts = {
            'nif': (
                'Le NIF doit être exact. Il servira de vérification lors de l\'inscription du chef. '
                'Le chef ne pourra pas s\'inscrire si ce NIF ne correspond pas.'
            ),
        }

    def clean_nif(self):
        nif = self.cleaned_data.get('nif', '').strip()
        # En mode création (pas d'instance) → vérifier unicité
        if not self.instance.pk and Societe.objects.filter(nif=nif).exists():
            raise forms.ValidationError(
                "Une société avec ce NIF existe déjà dans le système."
            )
        return nif




class CleActivationForm(forms.ModelForm):
    """
    Formulaire de génération de clé d'activation.

    La société est OBLIGATOIRE — chaque clé est liée à une société spécifique
    (identifiée par son nom + NIF, intégrés dans le code de la clé).

    Format généré : {NOM3}-{NIF4}-{PERIODE}-{ALEA6}
    Exemple       : SOD-4567-12M-AB3D4E

    Plans disponibles :
      - ESSAI      → 14 jours
      - STARTER    → 6 mois
      - BUSINESS   → 12 mois
      - ENTERPRISE → 24 mois
    """

    class Meta:
        model  = CleActivation
        fields = ['societe', 'type_plan', 'date_debut', 'date_fin', 'notes']
        widgets = {
            'societe':    forms.Select(attrs={'class': 'form-control'}),
            'type_plan':  forms.Select(attrs={'class': 'form-control', 'id': 'id_type_plan'}),
            'date_debut': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'date_fin':   forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'notes':      forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
        labels = {
            'societe':    'Société (obligatoire)',
            'type_plan':  'Type de plan',
            'date_debut': 'Valide à partir du',
            'date_fin':   "Valide jusqu'au (calculé automatiquement)",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['societe'].required    = True
        self.fields['date_debut'].required = False
        self.fields['date_fin'].required   = False

    def clean(self):
        cleaned    = super().clean()
        type_plan  = cleaned.get('type_plan')
        date_debut = cleaned.get('date_debut')
        date_fin   = cleaned.get('date_fin')

        if type_plan:
            # ✅ CORRECTION : utiliser timezone.now() (datetime aware) au lieu de date.today() (objet date)
            # Cela évite les erreurs de comparaison TypeError dans save()
            # entre timezone.now() (datetime aware) et date.today() (objet date)
            maintenant = timezone.now()
            if not date_debut:
                date_debut            = maintenant
                cleaned['date_debut'] = date_debut

            durees_jours = {'ESSAI': 14, 'STARTER': 182, 'BUSINESS': 365, 'ENTERPRISE': 730}
            if not date_fin:
                jours               = durees_jours.get(type_plan, 182)
                cleaned['date_fin'] = date_debut + timedelta(days=jours)
                date_fin            = cleaned['date_fin']

        if date_debut and date_fin and date_fin <= date_debut:
            raise forms.ValidationError("La date de fin doit être après la date de début.")

        return cleaned


# ─── Formulaire de révocation ───────────────────────────────────
class RevoquerCleForm(forms.Form):
    """Motif de révocation d'une clé (équivalent PHP 'suspendre_licence')."""
    motif = forms.CharField(
        label="Raison de la révocation",
        widget=forms.Textarea(attrs={
            'class': 'form-control', 'rows': 4,
            'placeholder': "Ex: Défaut de paiement, non-respect du contrat…"
        }),
        required=True,
    )


# ═══════════════════════════════════════════════════════════════
#  SETUP COMPLET — champs originaux de Societe
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  INSCRIPTION CHEF — Premier accès du chef de société
#
#  LOGIQUE :
#    1. Le superadmin a déjà enregistré la société + activé clé essai 14j
#    2. Le chef arrive sur /setup/ et remplit ce formulaire
#    3. Le système vérifie que le NIF a une clé ACTIVE en base
#    4. Si oui → société complétée + compte chef créé → connexion directe
#    5. Pas de clé à saisir — le NIF est le sésame d'accès
# ═══════════════════════════════════════════════════════════════

class InscriptionChefForm(forms.Form):
    """
    Formulaire d'inscription du chef de société.
    Remplace l'ancien SetupCompletForm.

    Le chef remplit :
      - Les informations complètes de sa société (NIF obligatoire)
      - Ses informations personnelles
      - Son username + password de connexion

    Validation clé :
      - Le NIF doit exister en base (enregistré par le superadmin)
      - Ce NIF doit avoir une clé d'essai ACTIVE (activée par le superadmin)
      - Sinon → inscription refusée avec message clair
    """

    # ── Section 1 : Informations de la société ───────────────────
    # ✅ Le chef saisit le nom OFFICIEL de sa société
    #    Le superadmin compare avec le nom qu'il a enregistré dans la fiche détail
    nom = forms.CharField(
        label="Nom officiel de la société", max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: SODECO SARL',
        }),
        help_text="Indiquez le nom exact tel qu'il apparaît sur vos documents officiels."
    )
    nif = forms.CharField(
        label="NIF (Numéro d'Identification Fiscale)", max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: 4000123456',
            'autocomplete': 'off',
        }),
        help_text=(
            "Votre NIF doit avoir été autorisé par l'administrateur système. "
            "Contactez-le si vous avez une erreur."
        )
    )
    registre = forms.CharField(
        label="Registre de commerce", max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: RC/BJ/2020/001',
        })
    )
    boite_postal = forms.CharField(
        label="Boîte postale", max_length=50, required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: BP 1234',
        })
    )
    telephone = forms.CharField(
        label="Téléphone de la société", max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: +257 22 123 456',
        })
    )
    province = forms.CharField(
        label="Province", max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ex: Bujumbura Mairie',
        })
    )
    commune = forms.CharField(
        label="Commune", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    quartier = forms.CharField(
        label="Quartier", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    avenue = forms.CharField(
        label="Avenue", max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    numero = forms.CharField(
        label="Numéro", max_length=20, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    centre_fiscale = forms.ChoiceField(
        label="Centre fiscal",
        choices=Societe.CENTRE_FISCALE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    assujeti_tva = forms.ChoiceField(
        label="Assujetti TVA",
        choices=[('True', 'Oui'), ('False', 'Non')],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    assujeti_tc = forms.ChoiceField(
        label="Assujetti à la TC",
        choices=[('True', 'Oui'), ('False', 'Non')],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
     # ── AJOUT : Forme juridique et Secteur d'activité ───────────
    forme = forms.CharField(
        label="Forme juridique", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: SARL, SA…'}),
        help_text="Indiquez la forme juridique de votre société."
    )
    secteur = forms.CharField(
        label="Secteur d'activité", max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Commerce, Services…'}),
        help_text="Indiquez le secteur d'activité principal de votre société."
    )


    # ── Section 2 : Informations du chef ─────────────────────────
    chef_nom = forms.CharField(
        label="Votre nom", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    chef_postnom = forms.CharField(
        label="Votre post-nom", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    chef_prenom = forms.CharField(
        label="Votre prénom", max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    chef_email = forms.EmailField(
        label="Votre email", required=False,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'chef@societe.com',
        })
    )

    # ── Section 3 : Compte de connexion ──────────────────────────
    chef_username = forms.CharField(
        label="Nom d'utilisateur", max_length=150,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'autocomplete': 'off',
            'placeholder': 'Ex: chef.sodeco',
        }),
        help_text="Ce nom sera utilisé pour se connecter à l'application."
    )
    chef_password1 = forms.CharField(
        label="Mot de passe", min_length=8,
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'autocomplete': 'new-password',
        }),
        help_text="Minimum 8 caractères."
    )
    chef_password2 = forms.CharField(
        label="Confirmer le mot de passe",
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'autocomplete': 'new-password',
        })
    )

    # ── Validations ───────────────────────────────────────────────

    def clean_nif(self):
        """
        Vérifie que le NIF saisi :
          1. Existe dans la base (société enregistrée par le superadmin)
          2. A une clé d'essai ACTIVE (autorisée par le superadmin)
          3. N'a pas encore de compte chef créé (premier accès uniquement)
        """
        from django.utils import timezone
        nif = self.cleaned_data.get('nif', '').strip()

        # Vérifier que la société existe (enregistrée par le superadmin)
        try:
            societe = Societe.objects.get(nif=nif)
        except Societe.DoesNotExist:
            raise forms.ValidationError(
                "Ce NIF n'est pas autorisé. Contactez l'administrateur système."
            )

        # Vérifier qu'une clé ACTIVE existe pour ce NIF
        now = timezone.now()
        cle_active = societe.cles_activation.filter(
            statut='ACTIVE',
            date_debut__lte=now,
            date_fin__gte=now,
        ).first()

        if cle_active is None:
            raise forms.ValidationError(
                "Aucune licence active pour ce NIF. "
                "Votre accès n'a pas encore été autorisé ou a expiré. "
                "Contactez l'administrateur système."
            )

        # Vérifier que la société n'a pas déjà un compte chef
        if Utilisateur.objects.filter(societe=societe, type_poste='DIRECTEUR').exists():
            raise forms.ValidationError(
                "Un compte existe déjà pour cette société. "
                "Utilisez la page de connexion ou contactez l'administrateur."
            )

        # Stocker pour réutilisation dans clean()
        self._societe     = societe
        self._cle_active  = cle_active
        return nif

    def clean_chef_username(self):
        username = self.cleaned_data.get('chef_username', '').strip()
        if Utilisateur.objects.filter(username=username).exists():
            raise forms.ValidationError(
                "Ce nom d'utilisateur est déjà utilisé. Choisissez-en un autre."
            )
        return username

    def clean(self):
        cleaned = super().clean()
        p1 = cleaned.get('chef_password1')
        p2 = cleaned.get('chef_password2')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError({
                'chef_password2': "Les deux mots de passe ne correspondent pas."
            })
        # Transmettre société et clé à la vue
        cleaned['_societe']    = getattr(self, '_societe', None)
        cleaned['_cle_active'] = getattr(self, '_cle_active', None)
        return cleaned


# ═══════════════════════════════════════════════════════════════
#  CLÉ PAYANTE — Saisie d'une clé de licence après l'essai
#
#  LOGIQUE :
#    Après 14 jours d'essai, le chef demande une licence payante
#    au superadmin. Il reçoit une clé du type : SOD-4567-12M-AB3D4E
#    Il la saisit dans l'application pour renouveler son accès.
# ═══════════════════════════════════════════════════════════════

class ClePayanteForm(forms.Form):
    """
    Formulaire de saisie d'une clé de licence payante.
    Utilisé par le chef après expiration de l'essai 14 jours.

    La clé est vérifiée contre :
      - Son existence en base
      - Son statut (DISPONIBLE uniquement)
      - Sa correspondance avec le NIF de la société connectée
      - Son intégrité HMAC
      - Ses dates de validité
    """
    cle_activation = forms.CharField(
        label="Clé de licence", max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': 'Ex: SOD-4567-12M-AB3D4E',
            'style': 'font-family: monospace; font-weight: bold; text-transform: uppercase; letter-spacing: 2px;',
            'autocomplete': 'off',
            'autofocus': 'autofocus',
        }),
        help_text="Clé reçue de l'administrateur système après votre période d'essai."
    )

    def clean_cle_activation(self):
        return self.cleaned_data.get('cle_activation', '').strip().upper()

    def verifier_pour_societe(self, societe):
        """
        Vérifie la clé payante pour une société donnée.
        Appelé depuis la vue après validation du formulaire.

        Retourne (success, message, cle_obj)
        """
        cle_saisie = self.cleaned_data.get('cle_activation', '')
        success, message, cle_obj = CleActivation.verifier_pour_setup(cle_saisie, societe.nif)
        return success, message, cle_obj



# ═══════════════════════════════════════════════════════════════
#  UTILISATEURS
# ═══════════════════════════════════════════════════════════════

_DROITS_WIDGETS = {
    'droit_stock_categorie':    forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_stock_produit':      forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_stock_fournisseur':  forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_stock_entree':       forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_stock_sortie':       forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_facture_pnb':        forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_facture_fdnb':       forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_facture_particulier':forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_devis':              forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'droit_rapports':           forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'is_superuser':             forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    'actif':                    forms.CheckboxInput(attrs={'class': 'form-check-input'}),
}

_CHAMPS_IDENTITE = ['nom', 'postnom', 'prenom', 'username', 'email', 'type_poste', 'photo']
_CHAMPS_DROITS   = list(_DROITS_WIDGETS.keys())


class UtilisateurCreationForm(UserCreationForm):
    password1 = forms.CharField(label="Mot de passe", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label="Confirmer",    widget=forms.PasswordInput(attrs={'class': 'form-control'}))

    class Meta:
        model  = Utilisateur
        fields = _CHAMPS_IDENTITE + _CHAMPS_DROITS
        widgets = {
            'nom':        forms.TextInput(attrs={'class': 'form-control'}),
            'postnom':    forms.TextInput(attrs={'class': 'form-control'}),
            'prenom':     forms.TextInput(attrs={'class': 'form-control'}),
            'username':   forms.TextInput(attrs={'class': 'form-control'}),
            'email':      forms.EmailInput(attrs={'class': 'form-control'}),
            'type_poste': forms.Select(attrs={'class': 'form-control'}),
            'photo':      forms.FileInput(attrs={'class': 'form-control'}),
            **_DROITS_WIDGETS,
        }


class UtilisateurModificationForm(forms.ModelForm):
    class Meta:
        model  = Utilisateur
        fields = _CHAMPS_IDENTITE + _CHAMPS_DROITS
        widgets = {
            'nom':        forms.TextInput(attrs={'class': 'form-control'}),
            'postnom':    forms.TextInput(attrs={'class': 'form-control'}),
            'prenom':     forms.TextInput(attrs={'class': 'form-control'}),
            'username':   forms.TextInput(attrs={'class': 'form-control'}),
            'email':      forms.EmailInput(attrs={'class': 'form-control'}),
            'type_poste': forms.Select(attrs={'class': 'form-control'}),
            'photo':      forms.FileInput(attrs={'class': 'form-control'}),
            **_DROITS_WIDGETS,
        }


class ChangerMotDePasseForm(forms.Form):
    nouveau_mot_de_passe = forms.CharField(
        label="Nouveau mot de passe", min_length=8,
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
    confirmer_mot_de_passe = forms.CharField(
        label="Confirmer le mot de passe",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )

    def clean(self):
        cleaned  = super().clean()
        password = cleaned.get('nouveau_mot_de_passe')
        confirm  = cleaned.get('confirmer_mot_de_passe')
        if password and confirm and password != confirm:
            raise forms.ValidationError("Les deux mots de passe ne correspondent pas.")
        return cleaned
