# rapports/utils.py
import os
from django.conf import settings
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from openpyxl import Workbook


def creer_dossier(type_export):
    """Crée le dossier MEDIA/rapports/{type_export}/ si absent."""
    chemin = os.path.join(settings.MEDIA_ROOT, 'rapports', type_export)
    os.makedirs(chemin, exist_ok=True)
    return chemin


def supprimer_ancien_fichier(chemin_complet):
    if os.path.exists(chemin_complet):
        os.remove(chemin_complet)


def generer_pdf(titre, colonnes, lignes, type_rapport):
    """Génère un fichier PDF et retourne son chemin relatif MEDIA."""
    dossier = creer_dossier('pdf')
    nom_fichier = f"{type_rapport}.pdf"
    chemin_complet = os.path.join(dossier, nom_fichier)

    supprimer_ancien_fichier(chemin_complet)

    doc = SimpleDocTemplate(chemin_complet, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph(titre, styles['Title']))
    elements.append(Spacer(1, 20))

    data = [colonnes] + lignes
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR',  (0, 0), (-1, 0), colors.whitesmoke),
        ('GRID',       (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME',   (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ALIGN',      (0, 0), (-1, -1), 'CENTER'),
    ]))

    elements.append(table)
    doc.build(elements)

    return f"rapports/pdf/{nom_fichier}"


def generer_excel(titre, colonnes, lignes, type_rapport):
    """Génère un fichier Excel et retourne son chemin relatif MEDIA."""
    dossier = creer_dossier('excel')
    nom_fichier = f"{type_rapport}.xlsx"
    chemin_complet = os.path.join(dossier, nom_fichier)

    supprimer_ancien_fichier(chemin_complet)

    wb = Workbook()
    ws = wb.active
    ws.title = titre[:31]  # Excel limite les noms d'onglets à 31 chars

    ws.append(colonnes)
    for ligne in lignes:
        ws.append(ligne)

    wb.save(chemin_complet)

    return f"rapports/excel/{nom_fichier}"
