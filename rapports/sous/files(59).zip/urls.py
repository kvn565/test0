# rapports/urls.py
from django.urls import path
from . import views

app_name = 'rapports'

urlpatterns = [
    path('entrees/',      views.rapport_entrees,      name='entrees'),
    path('cout-stock/',   views.rapport_cout_stock,   name='cout_stock'),
    path('sorties/',      views.rapport_sorties,      name='sorties'),
    path('stock-actuel/', views.rapport_stock_actuel, name='stock_actuel'),
    path('facturation/',  views.rapport_facturation,  name='facturation'),
]
