# rapports/models.py
# Pas de modèles — ce module utilise uniquement les modèles des autres apps.
