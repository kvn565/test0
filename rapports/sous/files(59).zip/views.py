# rapports/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count
from produits.models import Produit
from services.models import Service
from stock.models import EntreeStock, SortieStock
from facturer.models import Facture, LigneFacture


def get_filtres(request):
    return {
        'date_debut': request.GET.get('date_debut', ''),
        'date_fin':   request.GET.get('date_fin',   ''),
        'produit_id': request.GET.get('produit',    ''),
        'service_id': request.GET.get('service',    ''),
    }


def ctx_commun(f):
    return {
        **f,
        'produits': Produit.objects.all().order_by('designation'),
        'services': Service.objects.all().order_by('designation'),
    }


@login_required
def rapport_entrees(request):
    f  = get_filtres(request)
    qs = EntreeStock.objects.select_related('produit', 'fournisseur').order_by('-date_entree')
    if f['date_debut']: qs = qs.filter(date_entree__gte=f['date_debut'])
    if f['date_fin']:   qs = qs.filter(date_entree__lte=f['date_fin'])
    if f['produit_id']: qs = qs.filter(produit__id=f['produit_id'])
    totaux = qs.aggregate(nb=Count('id'), total_qte=Sum('quantite'), total_valeur=Sum('montant_total'))
    return render(request, 'rapports/entrees.html', {**ctx_commun(f), 'lignes': qs, 'totaux': totaux, 'rapport': 'entrees', 'reset_url': '/rapports/entrees/', 'titre': 'Entrées / Achats'})


@login_required
def rapport_cout_stock(request):
    f  = get_filtres(request)
    qs = LigneFacture.objects.select_related('facture', 'facture__client', 'produit', 'service').order_by('-facture__date_facture')
    if f['date_debut']: qs = qs.filter(facture__date_facture__gte=f['date_debut'])
    if f['date_fin']:   qs = qs.filter(facture__date_facture__lte=f['date_fin'])
    if f['produit_id']: qs = qs.filter(produit__id=f['produit_id'])
    if f['service_id']: qs = qs.filter(service__id=f['service_id'])
    ll = list(qs)
    return render(request, 'rapports/cout_stock.html', {
        **ctx_commun(f),
        'lignes': ll, 'nb': len(ll),
        'total_ht':  sum(l.montant_ht  for l in ll),
        'total_tva': sum(l.montant_tva for l in ll),
        'total_ttc': sum(l.montant_ttc for l in ll),
        'rapport': 'cout_stock', 'reset_url': '/rapports/cout-stock/', 'titre': 'Coût du Stock Vendu',
    })


@login_required
def rapport_sorties(request):
    f  = get_filtres(request)
    qs = SortieStock.objects.select_related('entree_stock', 'entree_stock__produit').order_by('-date_sortie')
    if f['date_debut']: qs = qs.filter(date_sortie__gte=f['date_debut'])
    if f['date_fin']:   qs = qs.filter(date_sortie__lte=f['date_fin'])
    if f['produit_id']: qs = qs.filter(entree_stock__produit__id=f['produit_id'])
    totaux = qs.aggregate(nb=Count('id'), total_qte=Sum('quantite'), total_valeur=Sum('montant_total'))
    return render(request, 'rapports/sorties.html', {**ctx_commun(f), 'lignes': qs, 'totaux': totaux, 'rapport': 'sorties', 'reset_url': '/rapports/sorties/', 'titre': 'Sorties / Ventes (hors facture)'})


@login_required
def rapport_stock_actuel(request):
    f = get_filtres(request)
    produits = Produit.objects.all().order_by('designation')
    if f['produit_id']: produits = produits.filter(id=f['produit_id'])
    lignes = []
    for p in produits:
        e = EntreeStock.objects.filter(produit=p)
        s = SortieStock.objects.filter(entree_stock__produit=p)
        v = LigneFacture.objects.filter(produit=p)
        if f['date_fin']:
            e = e.filter(date_entree__lte=f['date_fin'])
            s = s.filter(date_sortie__lte=f['date_fin'])
            v = v.filter(facture__date_facture__lte=f['date_fin'])
        qe = float(e.aggregate(t=Sum('quantite'))['t'] or 0)
        qs_val = float(s.aggregate(t=Sum('quantite'))['t'] or 0)
        qv = float(v.aggregate(t=Sum('quantite'))['t'] or 0)
        stock = qe - qs_val - qv
        ve = float(e.aggregate(v=Sum('montant_total'))['v'] or 0)
        pm = round(ve / qe, 2) if qe > 0 else 0
        lignes.append({'produit': p, 'qte_entree': qe, 'qte_sortie': qs_val, 'qte_vente': qv,
                       'stock': stock, 'prix_moyen': pm, 'valeur_stock': round(stock * pm, 2), 'alerte': stock <= 0})
    return render(request, 'rapports/stock_actuel.html', {
        **ctx_commun(f), 'lignes': lignes, 'nb': len(lignes),
        'total_valeur': sum(l['valeur_stock'] for l in lignes),
        'rapport': 'stock_actuel', 'reset_url': '/rapports/stock-actuel/', 'titre': 'État du Stock Actuel',
    })


@login_required
def rapport_facturation(request):
    f  = get_filtres(request)
    qs = Facture.objects.select_related('client').order_by('-date_facture')
    if f['date_debut']: qs = qs.filter(date_facture__gte=f['date_debut'])
    if f['date_fin']:   qs = qs.filter(date_facture__lte=f['date_fin'])
    if f['produit_id']: qs = qs.filter(lignes__produit__id=f['produit_id']).distinct()
    if f['service_id']: qs = qs.filter(lignes__service__id=f['service_id']).distinct()
    totaux = qs.aggregate(nb=Count('id'), total_ht=Sum('total_ht'), total_tva=Sum('total_tva'), total_ttc=Sum('total_ttc'))
    return render(request, 'rapports/facturation.html', {**ctx_commun(f), 'factures': qs, 'totaux': totaux, 'rapport': 'facturation', 'reset_url': '/rapports/facturation/', 'titre': 'Ventes / Facturation'})
