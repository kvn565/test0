# fournisseurs/models.py
from django.db import models

class Fournisseur(models.Model):
    nom       = models.CharField(max_length=150, unique=True, verbose_name="Nom")
    adresse   = models.CharField(max_length=250, blank=True, verbose_name="Adresse")
    telephone = models.CharField(max_length=20,  blank=True, verbose_name="Téléphone")
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Fournisseur"
        verbose_name_plural = "Fournisseurs"
        ordering = ['nom']

    def __str__(self):
        return self.nom
