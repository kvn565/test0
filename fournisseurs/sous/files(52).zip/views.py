# fournisseurs/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from .models import Fournisseur
from .forms import FournisseurForm


def fournisseur_liste(request):
    q = request.GET.get('q', '')
    fournisseurs = Fournisseur.objects.all()
    if q:
        fournisseurs = fournisseurs.filter(
            Q(nom__icontains=q) | Q(telephone__icontains=q) | Q(adresse__icontains=q)
        )
    return render(request, 'fournisseurs/liste.html', {
        'fournisseurs': fournisseurs,
        'q': q,
        'total': Fournisseur.objects.count(),
    })


def fournisseur_creer(request):
    if request.method == 'POST':
        form = FournisseurForm(request.POST)
        if form.is_valid():
            f = form.save()
            messages.success(request, f"Fournisseur « {f.nom} » créé avec succès.")
            return redirect('fournisseurs:liste')
    else:
        form = FournisseurForm()
    return render(request, 'fournisseurs/form.html', {
        'form': form,
        'titre': 'Nouveau fournisseur',
        'action': 'Créer',
    })


def fournisseur_modifier(request, pk):
    fournisseur = get_object_or_404(Fournisseur, pk=pk)
    if request.method == 'POST':
        form = FournisseurForm(request.POST, instance=fournisseur)
        if form.is_valid():
            form.save()
            messages.success(request, f"Fournisseur « {fournisseur.nom} » modifié.")
            return redirect('fournisseurs:liste')
    else:
        form = FournisseurForm(instance=fournisseur)
    return render(request, 'fournisseurs/form.html', {
        'form': form,
        'titre': 'Modifier le fournisseur',
        'action': 'Enregistrer',
        'fournisseur': fournisseur,
    })


def fournisseur_supprimer(request, pk):
    fournisseur = get_object_or_404(Fournisseur, pk=pk)
    if request.method == 'POST':
        nom = fournisseur.nom
        fournisseur.delete()
        messages.success(request, f"Fournisseur « {nom} » supprimé.")
        return redirect('fournisseurs:liste')
    return render(request, 'fournisseurs/supprimer.html', {'fournisseur': fournisseur})
