# fournisseurs/forms.py
from django import forms
from .models import Fournisseur

class FournisseurForm(forms.ModelForm):
    class Meta:
        model = Fournisseur
        fields = ['nom', 'adresse', 'telephone']
        widgets = {
            'nom':       forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: SODECO, BRARUDI...',
                'autofocus': True,
            }),
            'adresse':   forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: Avenue de la Paix, Bujumbura',
            }),
            'telephone': forms.TextInput(attrs={
                'class': 'form-control-custom',
                'placeholder': 'Ex: +257 22 123 456',
            }),
        }
        labels = {
            'nom':       'Nom du fournisseur',
            'adresse':   'Adresse',
            'telephone': 'Téléphone',
        }
