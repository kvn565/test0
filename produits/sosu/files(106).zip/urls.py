# produits/urls.py
from django.urls import path
from . import views

app_name = 'produits'

urlpatterns = [
    path('',                       views.produit_liste,          name='liste'),
    path('creer/local/',           views.produit_creer_local,    name='creer_local'),
    path('creer/importe/',         views.produit_creer_importe,  name='creer_importe'),
    path('<int:pk>/modifier/',     views.produit_modifier,       name='modifier'),
    path('<int:pk>/supprimer/',    views.produit_supprimer,      name='supprimer'),
]
