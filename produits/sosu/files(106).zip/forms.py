# produits/forms.py
from django import forms
from .models import Produit
from categories.models import Categorie
from taux.models import Taux


class ProduitForm(forms.ModelForm):

    def __init__(self, *args, societe=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.societe = societe

        self.fields['categorie'].empty_label = '-- Sélectionner une catégorie --'
        self.fields['taux_tva'].empty_label  = '-- Sélectionner un taux --'

        # Filtrer par société
        if societe:
            self.fields['categorie'].queryset = Categorie.objects.filter(societe=societe).order_by('nom')
            self.fields['taux_tva'].queryset  = Taux.objects.filter(societe=societe).order_by('valeur')
        else:
            self.fields['categorie'].queryset = Categorie.objects.none()
            self.fields['taux_tva'].queryset  = Taux.objects.none()

        # Labels
        self.fields['categorie'].label   = 'Catégorie'
        self.fields['code'].label        = 'Code produit'
        self.fields['designation'].label = 'Désignation'
        self.fields['unite'].label       = 'Unité de mesure'
        self.fields['prix_vente'].label  = 'Prix de vente'
        self.fields['devise'].label      = 'Devise'
        self.fields['taux_tva'].label    = 'Taux TVA'
        self.fields['statut'].label      = 'Statut'

    class Meta:
        model  = Produit
        fields = ['categorie', 'code', 'designation', 'unite', 'prix_vente', 'devise', 'taux_tva', 'statut']
        widgets = {
            'categorie': forms.Select(attrs={'class': 'form-select'}),
            'code':      forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: PROD-001',
            }),
            'designation': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Farine de blé 25kg',
            }),
            'unite': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: kg, litre, pièce, sac...',
            }),
            'prix_vente': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '0.00',
                'step': '0.01',
                'min': '0',
            }),
            'devise':   forms.Select(attrs={'class': 'form-select'}),
            'taux_tva': forms.Select(attrs={'class': 'form-select'}),
            'statut':   forms.Select(attrs={'class': 'form-select'}),
        }

    def clean_code(self):
        code = self.cleaned_data.get('code')
        if self.societe:
            qs = Produit.objects.filter(societe=self.societe, code__iexact=code)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError("Un produit avec ce code existe déjà pour votre société.")
        return code

    def save(self, commit=True):
        obj = super().save(commit=False)
        if self.societe:
            obj.societe = self.societe
        if commit:
            obj.save()
        return obj
