# produits/admin.py
from django.contrib import admin
from .models import Produit


@admin.register(Produit)
class ProduitAdmin(admin.ModelAdmin):
    list_display  = ['code', 'designation', 'societe', 'categorie', 'origine', 'prix_vente', 'devise', 'statut']
    list_filter   = ['societe', 'origine', 'statut', 'categorie']
    search_fields = ['code', 'designation']
