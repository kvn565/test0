# produits/models.py
from django.db import models
from societe.models import Societe
from categories.models import Categorie
from taux.models import Taux


class Produit(models.Model):

    ORIGINE_CHOICES = [
        ('LOCAL',   'Produit Local'),
        ('IMPORTE', 'Produit Importé'),
    ]

    STATUT_CHOICES = [
        ('ACTIF',     'Actif'),
        ('INACTIF',   'Inactif'),
        ('BROUILLON', 'Brouillon'),
    ]

    DEVISE_CHOICES = [
        ('BIF',  'BIF'),
        ('USD',  'USD'),
        ('EURO', 'EURO'),
    ]

    societe    = models.ForeignKey(Societe, on_delete=models.CASCADE, related_name='produits')
    categorie  = models.ForeignKey(Categorie, on_delete=models.CASCADE, related_name='produits', verbose_name="Catégorie")
    code       = models.CharField(max_length=50, verbose_name="Code")
    designation = models.CharField(max_length=200, verbose_name="Désignation")
    unite      = models.CharField(max_length=20, verbose_name="Unité")
    prix_vente = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Prix de vente")
    devise     = models.CharField(max_length=10, choices=DEVISE_CHOICES, default='BIF', verbose_name="Devise")
    taux_tva   = models.ForeignKey(
        Taux, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='produits', verbose_name="Taux TVA"
    )
    origine    = models.CharField(max_length=10, choices=ORIGINE_CHOICES, verbose_name="Origine")
    statut     = models.CharField(max_length=20, choices=STATUT_CHOICES, default='ACTIF', verbose_name="Statut")
    date_creation    = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Produit"
        verbose_name_plural = "Produits"
        ordering            = ['designation']
        unique_together     = [('societe', 'code')]

    def __str__(self):
        return self.designation

    @property
    def nb_entrees(self):
        return self.entrees_stock.count() if hasattr(self, 'entrees_stock') else 0
