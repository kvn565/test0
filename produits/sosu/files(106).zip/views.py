# produits/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .models import Produit
from .forms import ProduitForm
from categories.models import Categorie


def _check_droit(request):
    societe = getattr(request.user, 'societe', None)
    if not societe:
        return None, "Vous n'êtes rattaché à aucune société."
    type_poste = getattr(request.user, 'type_poste', None)
    if type_poste != 'DIRECTEUR' and not getattr(request.user, 'droit_stock_produit', False):
        return None, "Vous n'avez pas les droits pour gérer les produits."
    return societe, None


# ── LISTE ──────────────────────────────────────────────────────
@login_required
def produit_liste(request):
    societe, erreur = _check_droit(request)
    if erreur:
        messages.error(request, erreur)
        return redirect('accueil')

    q            = request.GET.get('q', '')
    origine      = request.GET.get('origine', '')
    statut_filtre = request.GET.get('statut', '')
    categorie_id = request.GET.get('categorie', '')

    produits = Produit.objects.filter(societe=societe).select_related('categorie', 'taux_tva')

    if q:
        produits = produits.filter(
            Q(code__icontains=q) |
            Q(designation__icontains=q) |
            Q(unite__icontains=q)
        )
    if origine:
        produits = produits.filter(origine=origine)
    if statut_filtre:
        produits = produits.filter(statut=statut_filtre)
    if categorie_id:
        produits = produits.filter(categorie_id=categorie_id)

    base_qs = Produit.objects.filter(societe=societe)
    stats = {
        'total':    base_qs.count(),
        'actifs':   base_qs.filter(statut='ACTIF').count(),
        'locaux':   base_qs.filter(origine='LOCAL').count(),
        'importes': base_qs.filter(origine='IMPORTE').count(),
    }

    return render(request, 'produits/produit_liste.html', {
        'produits':     produits,
        'categories':   Categorie.objects.filter(societe=societe).order_by('nom'),
        'stats':        stats,
        'q':            q,
        'origine':      origine,
        'statut':       statut_filtre,
        'categorie_id': categorie_id,
    })


# ── CRÉER PRODUIT LOCAL ────────────────────────────────────────
@login_required
def produit_creer_local(request):
    societe, erreur = _check_droit(request)
    if erreur:
        messages.error(request, erreur)
        return redirect('accueil')

    if request.method == 'POST':
        form = ProduitForm(request.POST, societe=societe)
        if form.is_valid():
            produit = form.save(commit=False)
            produit.origine = 'LOCAL'
            produit.societe = societe
            produit.save()
            messages.success(request, f"Produit « {produit.designation} » créé avec succès.")
            return redirect('produits:liste')
    else:
        form = ProduitForm(societe=societe)

    return render(request, 'produits/produit_form.html', {
        'form':    form,
        'titre':   'Nouveau Produit Local',
        'action':  'Créer',
        'origine': 'LOCAL',
    })


# ── CRÉER PRODUIT IMPORTÉ ──────────────────────────────────────
@login_required
def produit_creer_importe(request):
    societe, erreur = _check_droit(request)
    if erreur:
        messages.error(request, erreur)
        return redirect('accueil')

    if request.method == 'POST':
        form = ProduitForm(request.POST, societe=societe)
        if form.is_valid():
            produit = form.save(commit=False)
            produit.origine = 'IMPORTE'
            produit.societe = societe
            produit.save()
            messages.success(request, f"Produit « {produit.designation} » créé avec succès.")
            return redirect('produits:liste')
    else:
        form = ProduitForm(societe=societe)

    return render(request, 'produits/produit_form.html', {
        'form':    form,
        'titre':   'Nouveau Produit Importé',
        'action':  'Créer',
        'origine': 'IMPORTE',
    })


# ── MODIFIER ──────────────────────────────────────────────────
@login_required
def produit_modifier(request, pk):
    societe, erreur = _check_droit(request)
    if erreur:
        messages.error(request, erreur)
        return redirect('accueil')

    produit = get_object_or_404(
        Produit.objects.select_related('categorie', 'taux_tva'),
        pk=pk, societe=societe
    )

    if request.method == 'POST':
        form = ProduitForm(request.POST, instance=produit, societe=societe)
        if form.is_valid():
            form.save()
            messages.success(request, f"Produit « {produit.designation} » modifié avec succès.")
            return redirect('produits:liste')
    else:
        form = ProduitForm(instance=produit, societe=societe)

    return render(request, 'produits/produit_form.html', {
        'form':    form,
        'titre':   'Modifier le produit',
        'action':  'Enregistrer',
        'produit': produit,
        'origine': produit.origine,
    })


# ── SUPPRIMER ─────────────────────────────────────────────────
@login_required
def produit_supprimer(request, pk):
    societe, erreur = _check_droit(request)
    if erreur:
        messages.error(request, erreur)
        return redirect('accueil')

    produit = get_object_or_404(
        Produit.objects.select_related('categorie', 'taux_tva'),
        pk=pk, societe=societe
    )

    if request.method == 'POST':
        # Protection : entrées stock liées
        if produit.entrees_stock.exists():
            messages.error(request, f"Impossible de supprimer « {produit.designation} » : des entrées stock lui sont associées.")
            return redirect('produits:liste')
        nom = produit.designation
        produit.delete()
        messages.success(request, f"Produit « {nom} » supprimé.")
        return redirect('produits:liste')

    return render(request, 'produits/produit_supprimer.html', {'produit': produit})
