# produits/models.py
from django.db import models
from societe.models import Societe
from categories.models import Categorie
from taux.models import Taux


class Produit(models.Model):

    ORIGINE_CHOICES = [
        ('LOCAL',   'Produit Local'),
        ('IMPORTE', 'Produit Importé'),
    ]

    STATUT_CHOICES = [
        ('ACTIF',     'Actif'),
        ('INACTIF',   'Inactif'),
        ('BROUILLON', 'Brouillon'),
    ]

    DEVISE_CHOICES = [
        ('BIF',  'BIF'),
        ('USD',  'USD'),
        ('EURO', 'EURO'),
    ]

    societe     = models.ForeignKey(Societe, on_delete=models.CASCADE, related_name='produits')
    categorie   = models.ForeignKey(Categorie, on_delete=models.CASCADE, related_name='produits', verbose_name="Catégorie")
    code        = models.CharField(max_length=50, verbose_name="Code")
    designation = models.CharField(max_length=200, verbose_name="Désignation")
    unite       = models.CharField(max_length=20, verbose_name="Unité")
    prix_vente  = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Prix de vente")
    devise      = models.CharField(max_length=10, choices=DEVISE_CHOICES, default='BIF', verbose_name="Devise")
    taux_tva    = models.ForeignKey(
        Taux, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='produits', verbose_name="Taux TVA"
    )
    origine = models.CharField(max_length=10, choices=ORIGINE_CHOICES, verbose_name="Origine")
    statut  = models.CharField(max_length=20, choices=STATUT_CHOICES, default='ACTIF', verbose_name="Statut")

    # Champs OBR — Obligatoires pour les produits IMPORTÉS
    reference_dmc = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name="Référence DMC",
        help_text="Référence de la déclaration de mise en consommation. Ex: 2025BIPORC9",
    )
    rubrique_tarifaire = models.CharField(
        max_length=50, blank=True, default='',
        verbose_name="Rubrique tarifaire",
        help_text="Code dans le tarif douanier. Ex: 15119090000",
    )
    nombre_par_paquet = models.FloatField(
        null=True, blank=True,
        verbose_name="Nombre par paquet",
        help_text="Nombre de pièces par paquet. Ex: 300",
    )
    description_paquet = models.CharField(
        max_length=50, blank=True, default='',
        verbose_name="Description paquet",
        help_text="Type de conditionnement. Ex: carton, sacs, boîte",
    )

    date_creation     = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Produit"
        verbose_name_plural = "Produits"
        ordering            = ['designation']
        unique_together     = [('societe', 'code')]

    def __str__(self):
        return self.designation

    @property
    def nb_entrees(self):
        return self.entrees_stock.count() if hasattr(self, 'entrees_stock') else 0

    @property
    def est_importe(self):
        return self.origine == 'IMPORTE'

    @property
    def infos_import_completes(self):
        if not self.est_importe:
            return True
        return all([
            self.reference_dmc,
            self.rubrique_tarifaire,
            self.nombre_par_paquet,
            self.description_paquet,
        ])
