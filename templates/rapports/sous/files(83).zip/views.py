# rapports/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Avg

from produits.models import Produit
from services.models import Service
from stock.models import EntreeStock, SortieStock
from facturer.models import Facture, LigneFacture


# ══════════════════════════════════════════════
#  FILTRES COMMUNS
# ══════════════════════════════════════════════
def get_filtres(request):
    return {
        'date_debut': request.GET.get('date_debut', ''),
        'date_fin':   request.GET.get('date_fin', ''),
        'produit_id': request.GET.get('produit', ''),
        'service_id': request.GET.get('service', ''),
    }


def ctx_commun(f):
    return {
        **f,
        'produits': Produit.objects.all().order_by('designation'),
        'services': Service.objects.all().order_by('designation'),
    }


# ══════════════════════════════════════════════
#  RAPPORT ENTRÉES / ACHATS
# ══════════════════════════════════════════════
@login_required
def rapport_entrees(request):
    f = get_filtres(request)

    qs = EntreeStock.objects.select_related(
        'produit', 'produit__categorie', 'fournisseur'
    ).order_by('-date_entree')

    if f['date_debut']:
        qs = qs.filter(date_entree__gte=f['date_debut'])
    if f['date_fin']:
        qs = qs.filter(date_entree__lte=f['date_fin'])
    if f['produit_id']:
        qs = qs.filter(produit__id=f['produit_id'])

    totaux = qs.aggregate(
        nb=Count('id'),
        total_qte=Sum('quantite'),
        total_valeur=Sum('montant_total'),
    )

    return render(request, 'rapports/entrees.html', {
        **ctx_commun(f),
        'lignes':        qs,
        'totaux':        totaux,
        'titre':         'Entrées / Achats',
        'rapport':       'entrees',
        'rapport_icone': 'bi-box-arrow-in-down',
        'rapport_bg':    '#e0f2fe',
        'rapport_clr':   '#0284c7',
    })


# ══════════════════════════════════════════════
#  RAPPORT COÛT DU STOCK VENDU
# ══════════════════════════════════════════════
@login_required
def rapport_cout_stock(request):
    f = get_filtres(request)

    qs = LigneFacture.objects.select_related(
        'facture', 'facture__client',
        'produit', 'service'
    ).order_by('-facture__date_facture')

    if f['date_debut']:
        qs = qs.filter(facture__date_facture__gte=f['date_debut'])
    if f['date_fin']:
        qs = qs.filter(facture__date_facture__lte=f['date_fin'])
    if f['produit_id']:
        qs = qs.filter(produit__id=f['produit_id'])
    if f['service_id']:
        qs = qs.filter(service__id=f['service_id'])

    ll = list(qs)

    return render(request, 'rapports/cout_stock.html', {
        **ctx_commun(f),
        'lignes':        ll,
        'nb':            len(ll),
        'total_ht':      sum(l.montant_ht  for l in ll),
        'total_tva':     sum(l.montant_tva for l in ll),
        'total_ttc':     sum(l.montant_ttc for l in ll),
        'titre':         'Coût du Stock Vendu',
        'rapport':       'cout_stock',
        'rapport_icone': 'bi-calculator',
        'rapport_bg':    '#fef9c3',
        'rapport_clr':   '#b45309',
    })


# ══════════════════════════════════════════════
#  RAPPORT SORTIES / VENTE
# ══════════════════════════════════════════════
@login_required
def rapport_sorties(request):
    f = get_filtres(request)

    qs = SortieStock.objects.select_related(
        'entree_stock', 'entree_stock__produit',
        'entree_stock__produit__categorie'
    ).order_by('-date_sortie')

    if f['date_debut']:
        qs = qs.filter(date_sortie__gte=f['date_debut'])
    if f['date_fin']:
        qs = qs.filter(date_sortie__lte=f['date_fin'])
    if f['produit_id']:
        qs = qs.filter(entree_stock__produit__id=f['produit_id'])

    totaux = qs.aggregate(
        nb=Count('id'),
        total_qte=Sum('quantite'),
        total_valeur=Sum('montant_total'),
    )

    return render(request, 'rapports/sorties.html', {
        **ctx_commun(f),
        'lignes':        qs,
        'totaux':        totaux,
        'titre':         'Sorties / Ventes',
        'rapport':       'sorties',
        'rapport_icone': 'bi-box-arrow-up',
        'rapport_bg':    '#fdf4ff',
        'rapport_clr':   '#9333ea',
    })


# ══════════════════════════════════════════════
#  RAPPORT STOCK ACTUEL
# ══════════════════════════════════════════════
@login_required
def rapport_stock_actuel(request):
    f = get_filtres(request)

    produits_qs = Produit.objects.select_related(
        'categorie', 'taux_tva'
    ).all()

    if f['produit_id']:
        produits_qs = produits_qs.filter(id=f['produit_id'])

    lignes = []
    total_valeur = 0

    for p in produits_qs:
        # Quantités
        qte_entree = EntreeStock.objects.filter(produit=p).aggregate(
            t=Sum('quantite'))['t'] or 0
        qte_sortie = SortieStock.objects.filter(
            entree_stock__produit=p).aggregate(t=Sum('quantite'))['t'] or 0
        qte_vente = LigneFacture.objects.filter(
            produit=p).aggregate(t=Sum('quantite'))['t'] or 0

        stock = qte_entree - qte_sortie - qte_vente

        # Prix Moyen Pondéré (PMP)
        agg = EntreeStock.objects.filter(produit=p).aggregate(
            total_qte=Sum('quantite'),
            total_valeur=Sum('montant_total'),
        )
        if agg['total_qte']:
            prix_moyen = (agg['total_valeur'] or 0) / agg['total_qte']
        else:
            prix_moyen = float(p.prix_vente)

        valeur_stock = max(stock, 0) * prix_moyen
        total_valeur += valeur_stock

        lignes.append({
            'produit':     p,
            'qte_entree':  qte_entree,
            'qte_sortie':  qte_sortie,
            'qte_vente':   qte_vente,
            'stock':       stock,
            'prix_moyen':  round(prix_moyen, 2),
            'valeur_stock': round(valeur_stock, 2),
            'alerte':      stock <= 0,
        })

    # Trier : ruptures en premier
    lignes.sort(key=lambda x: x['alerte'], reverse=True)

    return render(request, 'rapports/stock_actuel.html', {
        **ctx_commun(f),
        'lignes':        lignes,
        'nb':            len(lignes),
        'total_valeur':  round(total_valeur, 2),
        'titre':         'Stock Actuel',
        'rapport':       'stock_actuel',
        'rapport_icone': 'bi-archive',
        'rapport_bg':    '#e8f5ee',
        'rapport_clr':   'var(--primary)',
    })


# ══════════════════════════════════════════════
#  RAPPORT FACTURATION
# ══════════════════════════════════════════════
@login_required
def rapport_facturation(request):
    f = get_filtres(request)

    qs = Facture.objects.select_related('client').order_by('-date_facture')

    if f['date_debut']:
        qs = qs.filter(date_facture__gte=f['date_debut'])
    if f['date_fin']:
        qs = qs.filter(date_facture__lte=f['date_fin'])
    if f['produit_id']:
        qs = qs.filter(lignes__produit__id=f['produit_id']).distinct()
    if f['service_id']:
        qs = qs.filter(lignes__service__id=f['service_id']).distinct()

    totaux = qs.aggregate(
        nb=Count('id'),
        total_ht=Sum('total_ht'),
        total_tva=Sum('total_tva'),
        total_ttc=Sum('total_ttc'),
        nb_clients=Count('client', distinct=True),
    )

    return render(request, 'rapports/facturation.html', {
        **ctx_commun(f),
        'factures':      qs,
        'totaux':        totaux,
        'titre':         'Ventes / Facturation',
        'rapport':       'facturation',
        'rapport_icone': 'bi-receipt',
        'rapport_bg':    '#e8f5ee',
        'rapport_clr':   'var(--primary)',
    })
