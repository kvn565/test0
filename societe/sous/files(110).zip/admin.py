# societe/admin.py
from django.contrib import admin
from .models import Societe
from .forms import SocieteOBRForm


@admin.register(Societe)
class SocieteAdmin(admin.ModelAdmin):
    list_display  = ['nom', 'nif', 'centre_fiscale', 'obr_actif', 'obr_configure', 'date_creation']
    list_filter   = ['centre_fiscale', 'obr_actif', 'assujeti_tva']
    search_fields = ['nom', 'nif']

    fieldsets = (
        ('Identité', {
            'fields': ('nom', 'nif', 'registre', 'telephone', 'boite_postal'),
        }),
        ('Adresse', {
            'fields': ('province', 'commune', 'quartier', 'avenue', 'numero'),
        }),
        ('Fiscalité', {
            'fields': ('centre_fiscale', 'assujeti_tva', 'assujeti_tc'),
        }),
        ('🔐 Configuration OBR (eBMS)', {
            'fields': ('obr_username', 'obr_password', 'obr_system_id', 'obr_actif'),
            'description': (
                'Ces informations sont fournies par l\'OBR lors de l\'enregistrement '
                'du système de facturation électronique. '
                'Contactez l\'OBR au 22282525 ou innocent.kanyanzira@obr.gov.bi'
            ),
        }),
    )

    @admin.display(boolean=True, description='OBR configuré')
    def obr_configure(self, obj):
        return obj.obr_configure
