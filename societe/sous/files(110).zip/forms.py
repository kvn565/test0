# societe/forms.py — VERSION AVEC CHAMPS OBR
from django import forms
from .models import Societe

W  = {'class': 'form-control'}
WS = {'class': 'form-select'}


class SocieteForm(forms.ModelForm):
    """
    Formulaire utilisé par le CHEF DE SOCIÉTÉ pour compléter
    ou modifier les informations de sa société.
    Le NIF n'est pas modifiable ici (fixé par le superadmin).
    Les champs OBR ne sont pas ici non plus (gérés par le superadmin).
    """
    class Meta:
        model  = Societe
        fields = [
            'nom', 'registre', 'boite_postal', 'telephone',
            'province', 'commune', 'quartier', 'avenue', 'numero',
            'centre_fiscale', 'assujeti_tva', 'assujeti_tc',
        ]
        widgets = {
            'nom':            forms.TextInput(attrs={**W, 'placeholder': 'Nom exact de la société'}),
            'registre':       forms.TextInput(attrs={**W, 'placeholder': 'N° Registre de commerce'}),
            'boite_postal':   forms.TextInput(attrs={**W, 'placeholder': 'Ex: BP 1234'}),
            'telephone':      forms.TextInput(attrs={**W, 'placeholder': 'Ex: +257 22 22 22 22'}),
            'province':       forms.TextInput(attrs={**W, 'placeholder': 'Ex: Bujumbura Mairie'}),
            'commune':        forms.TextInput(attrs={**W, 'placeholder': 'Ex: Mukaza'}),
            'quartier':       forms.TextInput(attrs={**W, 'placeholder': 'Ex: Rohero'}),
            'avenue':         forms.TextInput(attrs={**W, 'placeholder': "Ex: Avenue de la Liberté"}),
            'numero':         forms.TextInput(attrs={**W, 'placeholder': 'Ex: 12 (optionnel)'}),
            'centre_fiscale': forms.Select(attrs=WS),
            'assujeti_tva':   forms.Select(choices=[(True, 'Oui'), (False, 'Non')], attrs=WS),
            'assujeti_tc':    forms.Select(choices=[(True, 'Oui'), (False, 'Non')], attrs=WS),
        }
        labels = {
            'nom':            'Nom officiel de la société',
            'registre':       'Registre de commerce',
            'boite_postal':   'Boîte postale',
            'telephone':      'Téléphone',
            'province':       'Province',
            'commune':        'Commune / Commerce',
            'quartier':       'Quartier',
            'avenue':         'Avenue',
            'numero':         'Numéro',
            'centre_fiscale': 'Centre fiscal',
            'assujeti_tva':   'Assujetti TVA',
            'assujeti_tc':    'Assujetti à la TC',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['boite_postal'].required = False
        self.fields['numero'].required       = False


class SocieteOBRForm(forms.ModelForm):
    """
    Formulaire réservé au SUPERADMIN pour configurer
    les credentials OBR d'une société.
    Accessible depuis le panneau d'administration.
    """
    obr_password = forms.CharField(
        widget=forms.PasswordInput(attrs={**W, 'placeholder': 'Mot de passe OBR'}),
        label="Mot de passe OBR",
        required=False,
        help_text="Laissez vide pour ne pas modifier le mot de passe actuel.",
    )

    class Meta:
        model  = Societe
        fields = ['obr_username', 'obr_password', 'obr_system_id', 'obr_actif']
        widgets = {
            'obr_username':  forms.TextInput(attrs={
                **W, 'placeholder': 'Ex: user_societe_obr'
            }),
            'obr_system_id': forms.TextInput(attrs={
                **W, 'placeholder': 'Ex: ws440077324400027'
            }),
            'obr_actif': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'obr_username':  "Nom d'utilisateur OBR",
            'obr_password':  "Mot de passe OBR",
            'obr_system_id': "Identifiant système OBR",
            'obr_actif':     "Activer l'envoi OBR",
        }

    def save(self, commit=True):
        obj = super().save(commit=False)
        # Ne pas écraser le mot de passe si le champ est laissé vide
        password = self.cleaned_data.get('obr_password')
        if not password and self.instance.pk:
            obj.obr_password = Societe.objects.get(pk=self.instance.pk).obr_password
        if commit:
            obj.save()
        return obj
