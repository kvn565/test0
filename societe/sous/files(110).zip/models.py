# societe/models.py — VERSION AVEC CHAMPS OBR
from django.db import models
from django.utils import timezone


class Societe(models.Model):

    CENTRE_FISCALE_CHOICES = [
        ('DGC',    'DGC — Direction Générale des Contributions'),
        ('DMC',    'DMC — Direction des Moyennes Contributions'),
        ('DPMC',   'DPMC — Direction des Petites et Moyennes Contributions'),
        ('PRIVEE', 'Société Privée'),
        ('SU',     'SU — Service des Unités'),
    ]

    ASSUJETI_CHOICES = [
        (True,  'Oui'),
        (False, 'Non'),
    ]

    # ── Champs saisis par le SUPERADMIN ────────────────────────────────
    nom = models.CharField(max_length=200, verbose_name="Nom de la société")
    nif = models.CharField(
        max_length=50, unique=True,
        verbose_name="NIF",
        help_text="Doit être exact. Le chef ne pourra s'inscrire qu'avec ce NIF.",
    )

    # ── Champs complétés par le CHEF ────────────────────────────────────
    registre     = models.CharField(max_length=100, blank=True, default='', verbose_name="Registre de commerce")
    boite_postal = models.CharField(max_length=50, blank=True, null=True, verbose_name="Boîte postale")
    telephone    = models.CharField(max_length=50, blank=True, default='', verbose_name="Téléphone")

    # ── Adresse ─────────────────────────────────────────────────────────
    province = models.CharField(max_length=100, blank=True, default='', verbose_name="Province")
    commune  = models.CharField(max_length=100, blank=True, default='', verbose_name="Commune / Commerce")
    quartier = models.CharField(max_length=100, blank=True, default='', verbose_name="Quartier")
    avenue   = models.CharField(max_length=150, blank=True, default='', verbose_name="Avenue")
    numero   = models.CharField(max_length=20, blank=True, null=True, verbose_name="Numéro")

    # ── Fiscalité ────────────────────────────────────────────────────────
    centre_fiscale = models.CharField(
        max_length=10, blank=True, default='',
        choices=CENTRE_FISCALE_CHOICES,
        verbose_name="Centre fiscal",
    )
    assujeti_tva = models.BooleanField(choices=ASSUJETI_CHOICES, default=False, verbose_name="Assujetti TVA")
    assujeti_tc  = models.BooleanField(choices=ASSUJETI_CHOICES, default=False, verbose_name="Assujetti à la TC")

    # ══════════════════════════════════════════════════════════════════════
    #  CHAMPS OBR — Configurés par le SUPERADMIN
    #  Ces identifiants sont fournis par l'OBR lors de l'enregistrement
    #  du système de facturation électronique de la société.
    # ══════════════════════════════════════════════════════════════════════
    obr_username  = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name="Nom d'utilisateur OBR",
        help_text="Identifiant fourni par l'OBR pour l'accès à l'API eBMS.",
    )
    obr_password  = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name="Mot de passe OBR",
        help_text="Mot de passe fourni par l'OBR pour l'API eBMS.",
    )
    obr_system_id = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name="Identifiant système OBR",
        help_text="Ex: ws440077324400027 — fourni par l'OBR avec le mot de passe.",
    )
    obr_actif = models.BooleanField(
        default=False,
        verbose_name="Intégration OBR activée",
        help_text="Activer l'envoi automatique des données à l'OBR.",
    )

    # ── Traçabilité ──────────────────────────────────────────────────────
    date_creation     = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Société"
        verbose_name_plural = "Sociétés"
        ordering            = ['nom']

    def __str__(self):
        return f"{self.nom} (NIF: {self.nif})"

    @property
    def adresse_complete(self):
        parts = [self.avenue]
        if self.numero:
            parts.append(f"N°{self.numero}")
        parts += [self.quartier, self.commune, self.province]
        return ', '.join(p for p in parts if p)

    @property
    def cle_active(self):
        now = timezone.now()
        return self.cles_activation.filter(
            statut='ACTIVE',
            date_debut__lte=now,
            date_fin__gte=now,
        ).first()

    @property
    def licence_valide(self):
        return self.cle_active is not None

    @property
    def chef(self):
        return self.utilisateurs.filter(type_poste='DIRECTEUR').first()

    @property
    def inscription_complete(self):
        return self.utilisateurs.filter(type_poste='DIRECTEUR').exists()

    @property
    def infos_completes(self):
        return all([
            self.registre, self.telephone, self.province,
            self.commune, self.quartier, self.avenue, self.centre_fiscale,
        ])

    @property
    def obr_configure(self):
        """True si les credentials OBR sont tous renseignés."""
        return bool(self.obr_username and self.obr_password and self.obr_system_id)

    def get_tp_type(self):
        """
        Retourne le type de contribuable au format OBR.
        '1' = personne physique, '2' = personne morale (société).
        """
        return "2"  # Toujours personne morale pour une société

    def get_centre_fiscale_obr(self):
        """
        Retourne la valeur du centre fiscal au format attendu par l'OBR.
        L'OBR accepte : DGC, DMC, DPMC.
        """
        mapping = {
            'DGC':    'DGC',
            'DMC':    'DMC',
            'DPMC':   'DPMC',
            'PRIVEE': 'DMC',   # Valeur par défaut pour les privés
            'SU':     'DPMC',
        }
        return mapping.get(self.centre_fiscale, 'DMC')
