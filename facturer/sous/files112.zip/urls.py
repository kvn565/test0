# facturer/urls.py
from django.urls import path
from . import views

app_name = 'facturer'

urlpatterns = [
    # Pages
    path('',                           views.facture_liste,        name='liste'),
    path('<int:pk>/',                  views.facture_detail,       name='detail'),
    path('<int:pk>/supprimer/',        views.facture_supprimer,    name='supprimer'),

    path('<int:pk>/imprimer/a4/',      views.facture_imprimer_a4,  name='imprimer_a4'),
    path('<int:pk>/imprimer/pos/',     views.facture_imprimer_pos, name='imprimer_pos'),

    # AJAX
    path('ajax/creer/',                views.ajax_creer_facture,   name='ajax_creer'),
    path('ajax/info-produit/',         views.ajax_info_produit,    name='ajax_info_produit'),
    path('ajax/info-service/',         views.ajax_info_service,    name='ajax_info_service'),
    path('ajax/ajouter-ligne/',        views.ajax_ajouter_ligne,   name='ajax_ajouter_ligne'),
    path('ajax/supprimer-ligne/',      views.ajax_supprimer_ligne, name='ajax_supprimer_ligne'),
    path('ajax/modifier-ligne/',       views.ajax_modifier_ligne,  name='ajax_modifier_ligne'),
    path('ajax/envoyer-obr/',          views.ajax_envoyer_obr,     name='ajax_envoyer_obr'),
    path('ajax/annuler-obr/',          views.ajax_annuler_obr,     name='ajax_annuler_obr'),   # ✅ NOUVEAU
]
