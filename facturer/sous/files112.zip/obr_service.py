# facturer/obr_service.py
# ─────────────────────────────────────────────────────────────────
#  Service d'intégration OBR (Office Burundais des Recettes)
#  Endpoints : login → addInvoice / cancelInvoice
# ─────────────────────────────────────────────────────────────────

import requests
import logging

logger = logging.getLogger(__name__)

# ── URLs API OBR ──────────────────────────────────────────────────
OBR_URL_TEST       = "http://41.79.226.219:81"
OBR_URL_PRODUCTION = "http://41.79.226.219:81"   # à remplacer par l'URL prod réelle

ENDPOINT_LOGIN         = "/api/authenticate"
ENDPOINT_ADD_INVOICE   = "/api/addInvoice"
ENDPOINT_CANCEL_INVOICE = "/api/cancelInvoice"


def _get_base_url(societe):
    """Retourne l'URL de base selon le mode (test ou production)."""
    # Si vous ajoutez un champ `obr_mode` sur la société, vous pouvez switcher ici
    return OBR_URL_TEST


def _login(societe):
    """
    Authentification OBR.
    Retourne le token si succès, sinon lève une exception.
    """
    base_url = _get_base_url(societe)
    url      = base_url + ENDPOINT_LOGIN

    payload = {
        "tp_username":  societe.obr_username,
        "tp_password":  societe.obr_password,
        "tp_system_id": societe.obr_system_id,
    }

    try:
        resp = requests.post(url, json=payload, timeout=30)
        data = resp.json()
    except requests.exceptions.Timeout:
        raise Exception("⏱️ Délai de connexion OBR dépassé.")
    except requests.exceptions.ConnectionError:
        raise Exception("🔌 Impossible de joindre le serveur OBR. Vérifiez votre connexion.")
    except Exception as e:
        raise Exception(f"Erreur réseau OBR : {str(e)}")

    if not data.get("Result"):
        msg = data.get("msg") or data.get("msg_error") or "Échec de l'authentification OBR"
        raise Exception(f"🔐 Login OBR échoué : {msg}")

    token = data.get("token") or data.get("authorisation") or data.get("access_token")
    if not token:
        raise Exception("OBR n'a pas retourné de token d'authentification.")

    return token


def _build_invoice_payload(facture):
    """
    Construit le dictionnaire de données à envoyer à l'OBR pour addInvoice.
    Adapté au format attendu par l'API eBMS OBR Burundi.
    """
    societe = facture.societe
    client  = facture.client
    lignes  = facture.lignes.select_related('produit', 'service').all()

    # ── En-tête facture ──────────────────────────────────────────
    invoice_data = {
        "invoice_number":       facture.numero,
        "invoice_date":         str(facture.date_facture),
        "invoice_type":         facture.type_facture,        # FN ou FA
        "tp_type":              "T",                         # T = Taxable
        "payment_type":         facture.mode_paiement,
        "currency":             facture.devise,

        # ── Émetteur (société) ────────────────────────────────
        "tp_name":              societe.nom,
        "tp_TIN":               societe.nif,
        "tp_trade_number":      getattr(societe, 'registre_commerce', ''),
        "tp_postal_number":     getattr(societe, 'boite_postale', ''),
        "tp_phone_number":      getattr(societe, 'telephone', ''),
        "tp_address_commune":   getattr(societe, 'commune', ''),
        "tp_address_quartier":  getattr(societe, 'quartier', ''),
        "tp_address_avenue":    getattr(societe, 'avenue', ''),
        "tp_address_number":    getattr(societe, 'numero', ''),

        # ── Client ────────────────────────────────────────────
        "customer_name":        client.nom,
        "customer_TIN":         client.nif or "0000000000000",
        "customer_address":     getattr(client, 'adresse', ''),

        # ── Totaux ────────────────────────────────────────────
        "invoice_currency":     facture.devise,
        "invoice_conversion_rate": 1,
        "total_amount_excl_tax": float(facture.total_ht),
        "total_tax_amount":      float(facture.total_tva),
        "total_amount_incl_tax": float(facture.total_ttc),

        # ── Lignes ────────────────────────────────────────────
        "items": _build_items(lignes),
    }

    return {"invoice": invoice_data}


def _build_items(lignes):
    """Construit la liste des items/lignes pour le payload OBR."""
    items = []
    for i, ligne in enumerate(lignes, start=1):
        # Récupère la catégorie du produit si disponible
        item_type = "A"  # A = Article
        if ligne.service:
            item_type = "S"  # S = Service

        # Champs optionnels produit
        produit = ligne.produit
        items.append({
            "item_number":          i,
            "item_designation":     ligne.designation,
            "item_quantity":        float(ligne.quantite),
            "item_price":           float(ligne.prix_ht),
            "item_price_ttc":       float(ligne.prix_vente_tvac),
            "vat_rate":             float(ligne.taux_tva),
            "item_amount_excl_tax": float(ligne.montant_ht),
            "item_vat_amount":      float(ligne.montant_tva),
            "item_amount_incl_tax": float(ligne.montant_ttc),
            # Champs produit (si disponible)
            "item_code":            getattr(produit, 'code', '') if produit else '',
            "item_unit":            getattr(produit, 'unite', 'U') if produit else 'Prestation',
            "item_origin":          getattr(produit, 'origine', '') if produit else '',
        })
    return items


# ─────────────────────────────────────────────────────────────────
#  FONCTION PRINCIPALE — Envoyer une facture à l'OBR (addInvoice)
# ─────────────────────────────────────────────────────────────────

def envoyer_facture_obr(facture):
    """
    Envoie une facture à l'OBR via l'API addInvoice.

    Retourne un dict :
      - {'success': True,  'message': '...', 'signature': '...', 'qr_code': '...'}
      - {'success': False, 'message': '...'}
    """
    societe = facture.societe

    # Vérification des identifiants OBR sur la société
    if not all([societe.obr_username, societe.obr_password, societe.obr_system_id]):
        return {
            'success': False,
            'message': "❌ Identifiants OBR non configurés. Allez dans Superadmin > Sociétés > Section OBR."
        }

    try:
        # 1. Login
        token = _login(societe)

        # 2. Préparer le payload
        payload = _build_invoice_payload(facture)

        # 3. Envoyer à addInvoice
        base_url = _get_base_url(societe)
        url      = base_url + ENDPOINT_ADD_INVOICE
        headers  = {
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {token}",
        }

        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        data = resp.json()

        logger.info(f"OBR addInvoice réponse [{facture.numero}] : {data}")

        if data.get("Result"):
            return {
                'success':   True,
                'message':   data.get("msg") or "Facture envoyée avec succès à l'OBR.",
                'signature': data.get("invoice_registered", {}).get("electronic_signature", ""),
                'qr_code':   data.get("invoice_registered", {}).get("invoice_signature", ""),
            }
        else:
            msg = data.get("msg") or data.get("msg_error") or "Échec de l'envoi à l'OBR."
            return {'success': False, 'message': f"❌ OBR : {msg}"}

    except Exception as e:
        logger.error(f"Erreur OBR pour facture {facture.numero} : {e}")
        return {'success': False, 'message': str(e)}


# ─────────────────────────────────────────────────────────────────
#  ANNULER UNE FACTURE à l'OBR (cancelInvoice)
# ─────────────────────────────────────────────────────────────────

def annuler_facture_obr(facture, motif="Annulation"):
    """
    Annule une facture déjà envoyée à l'OBR.

    Retourne un dict :
      - {'success': True,  'message': '...'}
      - {'success': False, 'message': '...'}
    """
    societe = facture.societe

    if not all([societe.obr_username, societe.obr_password, societe.obr_system_id]):
        return {
            'success': False,
            'message': "❌ Identifiants OBR non configurés."
        }

    try:
        # 1. Login
        token = _login(societe)

        # 2. Payload annulation
        payload = {
            "invoice_number": facture.numero,
            "invoice_date":   str(facture.date_facture),
            "cancel_reason":  motif,
        }

        # 3. Appel cancelInvoice
        base_url = _get_base_url(societe)
        url      = base_url + ENDPOINT_CANCEL_INVOICE
        headers  = {
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {token}",
        }

        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        data = resp.json()

        logger.info(f"OBR cancelInvoice réponse [{facture.numero}] : {data}")

        if data.get("Result"):
            return {
                'success': True,
                'message': data.get("msg") or "Facture annulée avec succès à l'OBR.",
            }
        else:
            msg = data.get("msg") or data.get("msg_error") or "Échec de l'annulation."
            return {'success': False, 'message': f"❌ OBR : {msg}"}

    except Exception as e:
        logger.error(f"Erreur OBR annulation {facture.numero} : {e}")
        return {'success': False, 'message': str(e)}
