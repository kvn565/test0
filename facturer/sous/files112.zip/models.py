# facturer/models.py

from django.db import models
from societe.models import Societe
from clients.models import Client
from produits.models import Produit
from services.models import Service


class Facture(models.Model):
    TYPE_CHOICES = [
        ('FN', 'FN — Facture Normale'),
        ('FA', 'FA — Facture Avoir / Note de Crédit'),
    ]
    DEVISE_CHOICES = [
        ('BIF',  'BIF'),
        ('USD',  'USD'),
        ('EURO', 'EURO'),
    ]
    MODE_PAIEMENT_CHOICES = [
        ('CAISSE',  'Caisse'),
        ('BANQUE',  'Banque'),
        ('CREDIT',  'Crédit'),
        ('AUTRES',  'Autres'),
    ]
    STATUT_OBR_CHOICES = [
        ('EN_ATTENTE', 'En attente'),
        ('ENVOYE',     'Envoyé OBR'),
        ('ECHEC',      'Échec envoi'),
        ('ANNULE',     'Annulé OBR'),   # ✅ NOUVEAU
    ]

    # ── Société propriétaire ──────────────────────────────
    societe = models.ForeignKey(
        Societe,
        on_delete=models.CASCADE,
        related_name='factures',
        verbose_name="Société",
    )

    # ── Identification ────────────────────────────────────
    numero        = models.CharField(max_length=30, blank=True, verbose_name="N° Facture")
    date_facture  = models.DateField(verbose_name="Date")
    heure_facture = models.TimeField(verbose_name="Heure")
    type_facture  = models.CharField(max_length=5, choices=TYPE_CHOICES, verbose_name="Type")
    bon_commande  = models.CharField(max_length=100, blank=True, null=True, verbose_name="Bon de commande")

    # ── Client ────────────────────────────────────────────
    client = models.ForeignKey(
        Client,
        on_delete=models.PROTECT,
        related_name='factures',
        verbose_name="Client",
    )

    # ── Paiement ──────────────────────────────────────────
    devise        = models.CharField(max_length=5, choices=DEVISE_CHOICES, default='BIF', verbose_name="Devise")
    mode_paiement = models.CharField(max_length=10, choices=MODE_PAIEMENT_CHOICES, verbose_name="Mode de paiement")

    # ── Totaux calculés ───────────────────────────────────
    total_ht  = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_tva = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_ttc = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # ── Statut OBR ────────────────────────────────────────
    statut_obr      = models.CharField(max_length=20, choices=STATUT_OBR_CHOICES, default='EN_ATTENTE')
    message_obr     = models.TextField(blank=True)
    date_envoi_obr  = models.DateTimeField(null=True, blank=True)
    # ✅ NOUVEAU — Signature électronique retournée par l'OBR après addInvoice
    signature_obr   = models.TextField(blank=True, verbose_name="Signature électronique OBR")

    # ── Traçabilité ───────────────────────────────────────
    cree_par      = models.ForeignKey(
        'superadmin.Utilisateur',
        on_delete=models.SET_NULL,
        null=True,
        related_name='factures_creees',
    )
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Facture"
        verbose_name_plural = "Factures"
        ordering            = ['-date_creation']
        unique_together     = [('societe', 'numero')]

    def __str__(self):
        return f"{self.numero} — {self.client.nom}"

    def save(self, *args, **kwargs):
        if not self.numero and self.societe_id:
            from datetime import date as _date
            annee    = _date.today().year
            derniere = Facture.objects.filter(
                societe=self.societe,
                numero__startswith=f"{self.type_facture}-{annee}-"
            ).order_by('-numero').first()
            if derniere:
                try:
                    seq = int(derniere.numero.split('-')[-1]) + 1
                except (ValueError, IndexError):
                    seq = 1
            else:
                seq = 1
            self.numero = f"{self.type_facture}-{annee}-{seq:04d}"
        super().save(*args, **kwargs)

    def recalculer_totaux(self):
        from decimal import Decimal
        lignes = self.lignes.all()
        ht  = sum(Decimal(str(l.montant_ht))  for l in lignes)
        tva = sum(Decimal(str(l.montant_tva)) for l in lignes)
        ttc = sum(Decimal(str(l.montant_ttc)) for l in lignes)
        Facture.objects.filter(pk=self.pk).update(
            total_ht=ht,
            total_tva=tva,
            total_ttc=ttc,
        )
        self.total_ht  = ht
        self.total_tva = tva
        self.total_ttc = ttc

    @property
    def nb_lignes(self):
        return self.lignes.count()

    @property
    def peut_etre_supprimee(self):
        """Une facture envoyée à l'OBR ne devrait pas être supprimée."""
        return self.statut_obr not in ('ENVOYE', 'ANNULE')


class LigneFacture(models.Model):
    facture         = models.ForeignKey(Facture, on_delete=models.CASCADE, related_name='lignes')
    produit         = models.ForeignKey(Produit, on_delete=models.PROTECT, null=True, blank=True)
    service         = models.ForeignKey(Service, on_delete=models.PROTECT, null=True, blank=True)
    designation     = models.CharField(max_length=250, verbose_name="Désignation")
    quantite_stock  = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Qté en stock")
    taux_tva        = models.DecimalField(max_digits=5,  decimal_places=2, default=0,  verbose_name="TVA %")
    prix_vente_tvac = models.DecimalField(max_digits=12, decimal_places=2, verbose_name="Prix TVAC")
    quantite        = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Qté vendue")

    class Meta:
        ordering = ['id']

    def __str__(self):
        return self.designation

    @property
    def prix_ht(self):
        if self.taux_tva > 0:
            return round(float(self.prix_vente_tvac) / (1 + float(self.taux_tva) / 100), 2)
        return float(self.prix_vente_tvac)

    @property
    def montant_ht(self):
        return round(self.prix_ht * float(self.quantite), 2)

    @property
    def montant_tva(self):
        return round(float(self.montant_ht) * float(self.taux_tva) / 100, 2)

    @property
    def montant_ttc(self):
        return round(float(self.montant_ht) + float(self.montant_tva), 2)
