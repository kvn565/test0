# facturer/views.py

import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Q
from django.utils import timezone

from .models import Facture, LigneFacture
from .forms import FactureHeaderForm, LigneFactureForm
from produits.models import Produit
from services.models import Service


# ─────────────────────────────────────────────────────────────────
#  HELPER — Vérification droits
# ─────────────────────────────────────────────────────────────────

def _check_droit(request):
    """
    Vérifie que l'utilisateur a un droit de facturation.
    Retourne (societe, erreur).
    """
    if request.user.is_superuser:
        return None, "Superadmin n'a pas de société directe."

    societe = getattr(request.user, 'societe', None)
    if not societe:
        return None, "Aucune société associée à votre compte."

    a_droit = (
        request.user.droit_facture_pnb
        or request.user.droit_facture_fdnb
        or request.user.droit_facture_particulier
        or request.user.type_poste == 'DIRECTEUR'
    )
    if not a_droit:
        return None, "Vous n'avez pas les droits pour accéder à la facturation."

    return societe, None


def _get_societe_info(societe):
    """
    ✅ CORRECTION : retourne les infos de la société depuis la base de données
    au lieu d'un dictionnaire hardcodé ENTREPRISE_INFO.
    """
    return {
        'nom':             societe.nom,
        'nif':             societe.nif,
        'registre_commerce': getattr(societe, 'registre_commerce', ''),
        'telephone':       getattr(societe, 'telephone', ''),
        'adresse_complete': getattr(societe, 'adresse_complete', ''),
        'commune':         getattr(societe, 'commune', ''),
        'quartier':        getattr(societe, 'quartier', ''),
        'avenue':          getattr(societe, 'avenue', ''),
        'numero_rue':      getattr(societe, 'numero', ''),
        'assujeti_tva':    getattr(societe, 'assujeti_tva', False),
        'centre_fiscal':   getattr(societe, 'centre_fiscal', ''),
        'tc':              getattr(societe, 'tc', ''),
    }


# ─────────────────────────────────────────────────────────────────
#  LISTE FACTURES
# ─────────────────────────────────────────────────────────────────

@login_required
def facture_liste(request):
    societe, err = _check_droit(request)
    if err:
        messages.error(request, err)
        return redirect('accueil')

    # ✅ Filtre par société
    qs = Facture.objects.filter(societe=societe).select_related('client')

    q      = request.GET.get('q', '').strip()
    statut = request.GET.get('statut', '')
    type_f = request.GET.get('type', '')

    if q:
        qs = qs.filter(
            Q(numero__icontains=q)
            | Q(client__nom__icontains=q)
            | Q(bon_commande__icontains=q)
        )
    if statut:
        qs = qs.filter(statut_obr=statut)
    if type_f:
        qs = qs.filter(type_facture=type_f)

    # Stats filtrées par société
    base = Facture.objects.filter(societe=societe)
    stats = {
        'total':      base.count(),
        'en_attente': base.filter(statut_obr='EN_ATTENTE').count(),
        'envoyes':    base.filter(statut_obr='ENVOYE').count(),
        'echecs':     base.filter(statut_obr='ECHEC').count(),
    }

    return render(request, 'facturer/liste.html', {
        'facturer':    qs,
        'stats':       stats,
        'header_form': FactureHeaderForm(societe=societe),
        'q':           q,
        'statut':      statut,
        'type_f':      type_f,
        'types':       Facture.TYPE_CHOICES,
        'statuts':     Facture.STATUT_OBR_CHOICES,
        # ✅ Filtres produits/services par société pour la modal
        'produits_qs': Produit.objects.filter(societe=societe).order_by('designation'),
        'services_qs': Service.objects.filter(societe=societe).order_by('designation'),
    })


# ─────────────────────────────────────────────────────────────────
#  DÉTAIL FACTURE
# ─────────────────────────────────────────────────────────────────

@login_required
def facture_detail(request, pk):
    societe, err = _check_droit(request)
    if err:
        messages.error(request, err)
        return redirect('accueil')

    # ✅ Filtre par société → sécurité inter-sociétés
    facture = get_object_or_404(Facture.objects.select_related('client'), pk=pk, societe=societe)
    lignes  = facture.lignes.select_related('produit', 'service').all()

    return render(request, 'facturer/detail.html', {
        'facture':    facture,
        'lignes':     lignes,
        'ligne_form': LigneFactureForm(societe=societe),
        'produits':   Produit.objects.filter(societe=societe).order_by('designation'),
        'services':   Service.objects.filter(societe=societe).order_by('designation'),
    })


# ─────────────────────────────────────────────────────────────────
#  SUPPRIMER FACTURE
# ─────────────────────────────────────────────────────────────────

@login_required
def facture_supprimer(request, pk):
    societe, err = _check_droit(request)
    if err:
        messages.error(request, err)
        return redirect('accueil')

    facture = get_object_or_404(Facture, pk=pk, societe=societe)

    if request.method == 'POST':
        if not facture.peut_etre_supprimee:
            messages.error(request, "❌ Impossible de supprimer une facture déjà envoyée à l'OBR.")
            return redirect('facturer:detail', pk=pk)
        num = facture.numero
        facture.delete()
        messages.success(request, f"✅ Facture {num} supprimée.")
        return redirect('facturer:liste')

    return render(request, 'facturer/supprimer.html', {'facture': facture})


# ─────────────────────────────────────────────────────────────────
#  AJAX — CRÉER EN-TÊTE FACTURE (Modal 1 → Modal 2)
# ─────────────────────────────────────────────────────────────────

@login_required
@require_POST
def ajax_creer_facture(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False, 'error': err})

    form = FactureHeaderForm(societe=societe, data=request.POST)
    if form.is_valid():
        facture          = form.save(commit=False)
        facture.societe  = societe
        facture.cree_par = request.user
        facture.save()
        client = facture.client
        return JsonResponse({
            'ok':           True,
            'facture_id':   facture.pk,
            'numero':       facture.numero,
            'client_nom':   client.nom,
            'client_nif':   client.nif or '—',
            'assujeti':     'Oui' if client.assujeti_tva else 'Non',
            'type_facture': facture.get_type_facture_display(),
            'devise':       facture.devise,
        })
    return JsonResponse({'ok': False, 'errors': form.errors})


# ─────────────────────────────────────────────────────────────────
#  AJAX — INFO PRODUIT
# ─────────────────────────────────────────────────────────────────

@login_required
def ajax_info_produit(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False})

    pk = request.GET.get('pk')
    try:
        # ✅ Filtre par société — empêche d'accéder aux produits d'autres sociétés
        p = Produit.objects.get(pk=pk, societe=societe)

        # Calcul stock disponible (si module stock existant)
        stock_dispo = 0
        try:
            from stock.models import EntreeStock, SortieStock
            from django.db.models import Sum
            total_entree = EntreeStock.objects.filter(produit=p).aggregate(t=Sum('quantite'))['t'] or 0
            total_sortie = SortieStock.objects.filter(entree_stock__produit=p).aggregate(t=Sum('quantite'))['t'] or 0
            stock_dispo  = float(total_entree) - float(total_sortie)
        except ImportError:
            stock_dispo = 0

        return JsonResponse({
            'ok':          True,
            'designation': p.designation,
            'unite':       p.unite,
            'stock':       stock_dispo,
            'taux_tva':    float(p.taux_tva.valeur) if p.taux_tva else 0,
            'prix_ttc':    float(p.prix_vente),
            'type':        'produit',
        })
    except Produit.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Produit introuvable'})


# ─────────────────────────────────────────────────────────────────
#  AJAX — INFO SERVICE
# ─────────────────────────────────────────────────────────────────

@login_required
def ajax_info_service(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False})

    pk = request.GET.get('pk')
    try:
        # ✅ Filtre par société
        s = Service.objects.get(pk=pk, societe=societe)
        return JsonResponse({
            'ok':          True,
            'designation': s.designation,
            'unite':       getattr(s, 'unite', 'Prestation'),
            'stock':       '∞',
            # ✅ CORRECTION : utilise le vrai prix du service (plus hardcodé à 0)
            'taux_tva':    float(s.taux_tva.valeur) if getattr(s, 'taux_tva', None) else 0,
            'prix_ttc':    float(s.prix_vente) if hasattr(s, 'prix_vente') else 0,
            'type':        'service',
        })
    except Service.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Service introuvable'})


# ─────────────────────────────────────────────────────────────────
#  AJAX — AJOUTER LIGNE
# ─────────────────────────────────────────────────────────────────

@login_required
@require_POST
def ajax_ajouter_ligne(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False, 'error': err})

    data       = json.loads(request.body)
    facture_id = data.get('facture_id')

    # ✅ Filtre par société
    facture = get_object_or_404(Facture, pk=facture_id, societe=societe)

    produit_id  = data.get('produit_id')
    service_id  = data.get('service_id')
    quantite    = float(data.get('quantite', 0))
    prix_ttc    = float(data.get('prix_ttc', 0))
    taux_tva    = float(data.get('taux_tva', 0))
    stock       = data.get('stock', 0)
    designation = data.get('designation', '')

    if quantite <= 0:
        return JsonResponse({'ok': False, 'error': 'Quantité invalide'})
    if prix_ttc <= 0:
        return JsonResponse({'ok': False, 'error': 'Prix invalide'})
    if not designation:
        return JsonResponse({'ok': False, 'error': 'Désignation manquante'})

    # ✅ Filtre par société pour produit/service
    produit = None
    service = None
    if produit_id:
        try:
            produit = Produit.objects.get(pk=produit_id, societe=societe)
        except Produit.DoesNotExist:
            return JsonResponse({'ok': False, 'error': 'Produit invalide'})
    if service_id:
        try:
            service = Service.objects.get(pk=service_id, societe=societe)
        except Service.DoesNotExist:
            return JsonResponse({'ok': False, 'error': 'Service invalide'})

    ligne = LigneFacture.objects.create(
        facture         = facture,
        produit         = produit,
        service         = service,
        designation     = designation,
        quantite_stock  = stock if stock != '∞' else 0,
        taux_tva        = taux_tva,
        prix_vente_tvac = prix_ttc,
        quantite        = quantite,
    )
    facture.recalculer_totaux()

    return JsonResponse({
        'ok':          True,
        'ligne_id':    ligne.pk,
        'designation': ligne.designation,
        'stock':       str(stock),
        'taux_tva':    taux_tva,
        'prix_ttc':    prix_ttc,
        'quantite':    quantite,
        'montant_ht':  ligne.montant_ht,
        'montant_tva': ligne.montant_tva,
        'montant_ttc': ligne.montant_ttc,
        'total_ht':    float(facture.total_ht),
        'total_tva':   float(facture.total_tva),
        'total_ttc':   float(facture.total_ttc),
    })


# ─────────────────────────────────────────────────────────────────
#  AJAX — SUPPRIMER LIGNE
# ─────────────────────────────────────────────────────────────────

@login_required
@require_POST
def ajax_supprimer_ligne(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False, 'error': err})

    data     = json.loads(request.body)
    ligne_id = data.get('ligne_id')

    # ✅ Sécurité : vérifie que la ligne appartient à une facture de la société
    ligne = get_object_or_404(LigneFacture, pk=ligne_id, facture__societe=societe)
    facture = ligne.facture
    ligne.delete()
    facture.recalculer_totaux()

    return JsonResponse({
        'ok':        True,
        'total_ht':  float(facture.total_ht),
        'total_tva': float(facture.total_tva),
        'total_ttc': float(facture.total_ttc),
    })


# ─────────────────────────────────────────────────────────────────
#  AJAX — MODIFIER LIGNE
# ─────────────────────────────────────────────────────────────────

@login_required
@require_POST
def ajax_modifier_ligne(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False, 'error': err})

    data  = json.loads(request.body)
    # ✅ Filtre par société
    ligne = get_object_or_404(LigneFacture, pk=data.get('ligne_id'), facture__societe=societe)

    ligne.quantite        = float(data.get('quantite', ligne.quantite))
    ligne.prix_vente_tvac = float(data.get('prix_ttc', ligne.prix_vente_tvac))
    ligne.save()
    ligne.facture.recalculer_totaux()

    return JsonResponse({
        'ok':          True,
        'montant_ht':  ligne.montant_ht,
        'montant_tva': ligne.montant_tva,
        'montant_ttc': ligne.montant_ttc,
        'total_ht':    float(ligne.facture.total_ht),
        'total_tva':   float(ligne.facture.total_tva),
        'total_ttc':   float(ligne.facture.total_ttc),
    })


# ─────────────────────────────────────────────────────────────────
#  AJAX — ENVOYER À L'OBR
# ─────────────────────────────────────────────────────────────────

@login_required
@require_POST
def ajax_envoyer_obr(request):
    societe, err = _check_droit(request)
    if err:
        return JsonResponse({'ok': False, 'error': err})

    data    = json.loads(request.body)
    # ✅ Filtre par société
    facture = get_object_or_404(Facture, pk=data.get('facture_id'), societe=societe)

    if facture.nb_lignes == 0:
        return JsonResponse({'ok': False, 'error': 'La facture est vide — ajoutez au moins une ligne.'})

    # Placeholder — intégration API OBR ici
    facture.statut_obr     = 'ENVOYE'
    facture.message_obr    = 'Opération effectuée avec succès'
    facture.date_envoi_obr = timezone.now()
    facture.save()

    return JsonResponse({'ok': True, 'message': facture.message_obr})


# ─────────────────────────────────────────────────────────────────
#  IMPRESSION A4
# ─────────────────────────────────────────────────────────────────

@login_required
def facture_imprimer_a4(request, pk):
    societe, err = _check_droit(request)
    if err:
        messages.error(request, err)
        return redirect('accueil')

    facture = get_object_or_404(Facture.objects.select_related('client'), pk=pk, societe=societe)
    lignes  = facture.lignes.select_related('produit', 'service').all()

    # Montant en lettres (pip install num2words)
    montant_lettres = ''
    try:
        from num2words import num2words
        montant_lettres = num2words(int(facture.total_ttc), lang='fr').capitalize() + ' francs burundais.'
    except ImportError:
        pass

    return render(request, 'facturer/print_a4.html', {
        'facture':         facture,
        'lignes':          lignes,
        # ✅ CORRECTION : infos société depuis la base, pas un dict hardcodé
        'entreprise':      _get_societe_info(societe),
        'montant_lettres': montant_lettres,
        'qr_code_url':     None,
    })


# ─────────────────────────────────────────────────────────────────
#  IMPRESSION POS (ticket thermique)
# ─────────────────────────────────────────────────────────────────

@login_required
def facture_imprimer_pos(request, pk):
    societe, err = _check_droit(request)
    if err:
        messages.error(request, err)
        return redirect('accueil')

    facture = get_object_or_404(Facture.objects.select_related('client'), pk=pk, societe=societe)
    lignes  = facture.lignes.select_related('produit', 'service').all()

    montant_lettres = ''
    try:
        from num2words import num2words
        montant_lettres = num2words(int(facture.total_ttc), lang='fr').capitalize() + ' francs burundais.'
    except ImportError:
        pass

    return render(request, 'facturer/print_pos.html', {
        'facture':         facture,
        'lignes':          lignes,
        'entreprise':      _get_societe_info(societe),
        'montant_lettres': montant_lettres,
        'qr_code_url':     None,
    })
