# facturer/forms.py

from django import forms
from datetime import date, datetime
from .models import Facture, LigneFacture
from clients.models import Client
from produits.models import Produit
from services.models import Service


class FactureHeaderForm(forms.ModelForm):
    """
    Modal 1 — En-tête de la facture.
    Reçoit `societe` pour filtrer les clients disponibles.
    """
    class Meta:
        model  = Facture
        fields = ['date_facture', 'heure_facture', 'client', 'type_facture',
                  'bon_commande', 'devise', 'mode_paiement']
        widgets = {
            'date_facture':  forms.DateInput(attrs={
                'class': 'form-control', 'type': 'date',     # ✅ CORRIGÉ
            }),
            'heure_facture': forms.TimeInput(attrs={
                'class': 'form-control', 'type': 'time',     # ✅ CORRIGÉ
            }),
            'client':        forms.Select(attrs={'class': 'form-select'}),
            'type_facture':  forms.Select(attrs={'class': 'form-select'}),
            'bon_commande':  forms.TextInput(attrs={
                'class':       'form-control',
                'placeholder': 'N° bon de commande (optionnel)',  # ✅ CORRIGÉ encodage
            }),
            'devise':        forms.Select(attrs={'class': 'form-select'}),
            'mode_paiement': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, societe=None, *args, **kwargs):
        self.societe = societe
        super().__init__(*args, **kwargs)

        # ✅ CORRECTION : filtrer les clients par société
        if societe:
            self.fields['client'].queryset = (
                Client.objects.filter(societe=societe).order_by('nom')
            )
        else:
            self.fields['client'].queryset = Client.objects.none()

        self.fields['client'].empty_label    = '-- Sélectionner un client --'   # ✅ CORRIGÉ
        self.fields['bon_commande'].required = False

        if not self.instance.pk:
            self.fields['date_facture'].initial  = date.today()
            self.fields['heure_facture'].initial = datetime.now().strftime('%H:%M')


class LigneFactureForm(forms.ModelForm):
    """
    Modal 2 — Ligne de détail.
    Reçoit `societe` pour filtrer produits et services.
    """
    class Meta:
        model  = LigneFacture
        fields = ['produit', 'service', 'quantite']
        widgets = {
            'produit': forms.Select(attrs={
                'class': 'form-select',
                'id':    'id_ligne_produit',
            }),
            'service': forms.Select(attrs={
                'class': 'form-select',
                'id':    'id_ligne_service',
            }),
            'quantite': forms.NumberInput(attrs={
                'class':       'form-control',
                'step':        '0.01',
                'min':         '0.01',
                'id':          'id_ligne_quantite',
                'placeholder': '0',
            }),
        }

    def __init__(self, societe=None, *args, **kwargs):
        self.societe = societe
        super().__init__(*args, **kwargs)

        self.fields['produit'].empty_label = '-- Choisir un produit --'
        self.fields['service'].empty_label = '-- Choisir un service --'
        self.fields['produit'].required    = False
        self.fields['service'].required    = False

        # ✅ CORRECTION : filtrer par société
        if societe:
            self.fields['produit'].queryset = (
                Produit.objects.filter(societe=societe).order_by('designation')
            )
            self.fields['service'].queryset = (
                Service.objects.filter(societe=societe).order_by('designation')
            )
        else:
            self.fields['produit'].queryset = Produit.objects.none()
            self.fields['service'].queryset = Service.objects.none()
